# F25 Design Tokens — Cross-reference to QA Nexus globals.css

This bundle uses **only locked tokens** from `apps/web/app/globals.css`. The F25 HTML design defines a `--p-*` ("prove") namespace that the React components route through. **No new colors. No new fonts.**

## Workspace chrome tokens (used by AdminShell, not redefined here)

| Token | Hex | Used for |
|---|---|---|
| `--canvas` | `#0B0F17` | Workspace background (rail + top bar) |
| `--base` | `#111827` | Card surface (rail items, top bar bg) |
| `--raised` | `#1A2233` | Hover / raised state |
| `--overlay` | `#232C3F` | Active nav item bg |
| `--border` | `#2A3347` | Default border |
| `--border-strong` | `#3B4660` | Emphasis border |
| `--t1` | `#F1F5F9` | Primary text |
| `--t2` | `#C7D0DC` | Secondary text |
| `--t3` | `#8A94A6` | Tertiary text |
| `--t4` | `#64748B` | Disabled / dim |
| `--primary` | `#2DD4BF` | Teal — primary CTAs, system actions |
| `--secondary` | `#A78BFA` | Violet — AI surfaces |
| `--ai-accent` | `#C4B5FD` | Violet hover/highlight |
| `--pass` | `#34D399` | Green |
| `--fail` | `#F87171` | Red |
| `--warn` | `#FBBF24` | Amber |
| `--info` | `#60A5FA` | Blue |
| `--rail-w` | `240px` (collapsed `64px`) | Left rail width |
| `--topbar-h` | `56px` | Top bar height |
| `--tap` | `44px` | Minimum tap target |

## F25 Prove-mode tokens (light variant)

These extend the workspace chrome — used only inside the `<main>` content area, never on rail/topbar.

| Token | Hex | Used for |
|---|---|---|
| `--p-canvas` | `#FAFAF8` | Ivory page canvas |
| `--p-card` | `#FFFFFF` | KPI cards, readiness gates, approval row |
| `--p-card-soft` | `#F4F4F0` | Inset blocks (formula, benchmark, severity bars) |
| `--p-border` | `#E5E7EB` | Default card border |
| `--p-border-strong` | `#CBD5E1` | Emphasis border (buttons, dividers) |
| `--p-text-1` | `#0F172A` | Primary text |
| `--p-text-2` | `#475569` | Secondary text |
| `--p-text-3` | `#64748B` | Tertiary / labels |
| `--p-text-4` | `#94A3B8` | Disabled / dim |
| `--p-pass` | `#10B981` | Green (passing gates, downward defect trend) |
| `--p-pass-bg` | `#D1FAE5` | Green chip background |
| `--p-pass-line` | `#A7F3D0` | Green chip border |
| `--p-warn` | `#D97706` | Amber (open-defects block, pending approval) |
| `--p-warn-bg` | `#FEF3C7` | |
| `--p-warn-line` | `#FCD34D` | |
| `--p-fail` | `#DC2626` | Red (P0 defect pill) |
| `--p-fail-bg` | `#FEE2E2` | |
| `--p-fail-line` | `#FCA5A5` | |
| `--p-info` | `#2563EB` | Blue (links inside ivory) |
| `--p-info-bg` | `#DBEAFE` | |
| `--p-secondary` | `#7C3AED` | Violet — agent tooltips, recommendation panel accent |
| `--p-secondary-bg` | `#EDE9FE` | |
| `--p-secondary-line` | `#DDD6FE` | |
| `--p-primary` | `#0D9488` | Teal — ROI hero accent, approval primary button, chart series |
| `--p-primary-bg` | `#CCFBF1` | |

## F25 Prove-mode tokens (dark variant)

The dark variant (`F25 Executive Dashboard v2 -Dark-.html`) remaps the `--p-*` family — **no other CSS changes**. Single-block swap:

| Token | Light | Dark |
|---|---|---|
| `--p-canvas` | `#FAFAF8` | `#0B0F17` |
| `--p-card` | `#FFFFFF` | `#111827` |
| `--p-card-soft` | `#F4F4F0` | `#1A2233` |
| `--p-text-1` | `#0F172A` | `#F1F5F9` |
| `--p-pass` | `#10B981` | `#34D399` |
| `--p-warn` | `#D97706` | `#FBBF24` |
| `--p-fail` | `#DC2626` | `#F87171` |
| `--p-secondary` | `#7C3AED` | `#A78BFA` |
| `--p-primary` | `#0D9488` | `#2DD4BF` |
| `*-bg` (solid pastels) | solid hex | alpha tints on canvas (e.g. `rgba(52,211,153,0.14)`) |
| `*-line` (solid borders) | solid hex | alpha tints (e.g. `rgba(52,211,153,0.34)`) |

**Implementation tip:** In React, route both variants through CSS variables on a wrapping element:

```tsx
<div className="f25-shell" data-theme={theme}>
  {/* both light and dark share the same className tree; only --p-* swaps */}
</div>
```

```css
.f25-shell[data-theme="dark"] {
  --p-canvas: #0B0F17;
  --p-card: #111827;
  /* … */
}
```

## Typography

| Family | Used for |
|---|---|
| `'DM Sans'` | Display — page titles, hero numbers (ROI), section labels |
| `'Inter'` | Body — paragraphs, secondary text, button labels |
| `'JetBrains Mono'` | Numerics — KPI values, defect counts, formula breakdowns, timestamps, agent tags |

All three are already loaded in `globals.css`. **Never** introduce additional families.

## Geometry

| Property | Value | Notes |
|---|---|---|
| `--r-sm` | `6px` | Buttons, chips |
| `--r-md` | `8px` | Form inputs, inset blocks |
| `--r-lg` | `12px` | Cards, panels |
| KPI card min-height | `160px` (mobile) → `180px` (≥768px) | Quality + Risk grids |
| Mini-chart height | `96px` | Trends row |
| Tap target | `≥44×44px` on coarse pointer | All interactive elements |
