'use client'

import { f25Demo } from '../data/canned-data'
import { Check } from 'lucide-react'

/**
 * Quality posture — 3 KPI cards.
 *
 * Cards: pass rate (with severity breakdown bars), coverage
 * (with automated/manual/untested segment bar), defect density
 * (with industry benchmark callout).
 */
export function QualityPostureGrid() {
  const { quality } = f25Demo

  return (
    <section
      data-canonical-section="quality-posture"
      role="region"
      aria-label="Quality posture"
    >
      <h2 className="font-[DM_Sans] text-[12.5px] leading-[18px] font-bold text-[color:var(--p-text-1)] m-0 mb-2.5 uppercase tracking-[0.08em] inline-flex items-center gap-2 flex-wrap">
        Quality posture
        <span className="font-[JetBrains_Mono] text-[10.5px] font-semibold text-[color:var(--p-text-3)] bg-[color:var(--p-card)] px-1.5 py-0.5 rounded-full leading-none border border-[color:var(--p-border)] normal-case tracking-normal">
          3 metrics
        </span>
      </h2>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-3.5 lg:grid-cols-3 lg:gap-4">
        {/* Pass rate */}
        <KpiCard label="Test pass rate" trend={quality.passRate.trend} trendDirection={quality.passRate.trendDirection}>
          <Metric value={quality.passRate.value.toString()} unit={quality.passRate.unit} />
          <p className="text-[13px] leading-[18px] text-[color:var(--p-text-2)] font-medium m-0">{quality.passRate.sub}</p>
          <div className="flex flex-col gap-1.5 mt-auto">
            {quality.passRate.severityBreakdown.map((row) => (
              <div key={row.label} className="grid grid-cols-[70px_1fr_36px] items-center gap-2 text-[11px] text-[color:var(--p-text-2)]">
                <span className="font-medium">{row.label}</span>
                <div className="h-[5px] bg-[color:var(--p-card-soft)] rounded-full border border-[color:var(--p-border)] overflow-hidden">
                  <span className="block h-full bg-[color:var(--p-primary)]" style={{ width: `${row.pct}%` }} />
                </div>
                <span className="font-[JetBrains_Mono] font-semibold text-[color:var(--p-text-1)] text-right text-[11px]">{row.pct}%</span>
              </div>
            ))}
          </div>
        </KpiCard>

        {/* Coverage */}
        <KpiCard label="Test coverage" trend={quality.coverage.trend} trendDirection={quality.coverage.trendDirection}>
          <Metric value={quality.coverage.value.toString()} unit={quality.coverage.unit} />
          <p className="text-[13px] leading-[18px] text-[color:var(--p-text-2)] font-medium m-0">{quality.coverage.sub}</p>
          <div
            role="img"
            aria-label={`Coverage breakdown: ${quality.coverage.breakdown.automated}% automated, ${quality.coverage.breakdown.manual}% manual, ${quality.coverage.breakdown.untested}% untested`}
            className="flex h-2 rounded-full overflow-hidden bg-[color:var(--p-card-soft)] border border-[color:var(--p-border)] mt-1"
          >
            <span className="block h-full bg-[color:var(--p-primary)]" style={{ width: `${quality.coverage.breakdown.automated}%` }} />
            <span className="block h-full bg-[color:var(--p-text-3)]" style={{ width: `${quality.coverage.breakdown.manual}%` }} />
            <span className="block h-full bg-[color:var(--p-border)]" style={{ width: `${quality.coverage.breakdown.untested}%` }} />
          </div>
          <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[10.5px] text-[color:var(--p-text-3)] mt-1.5">
            <span className="inline-flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-[color:var(--p-primary)] shrink-0" />
              Automated <span className="text-[color:var(--p-text-1)] font-[JetBrains_Mono] font-semibold ml-0.5">{quality.coverage.breakdown.automated}%</span>
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-[color:var(--p-text-3)] shrink-0" />
              Manual <span className="text-[color:var(--p-text-1)] font-[JetBrains_Mono] font-semibold ml-0.5">{quality.coverage.breakdown.manual}%</span>
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-[color:var(--p-border)] shrink-0" />
              Untested <span className="text-[color:var(--p-text-1)] font-[JetBrains_Mono] font-semibold ml-0.5">{quality.coverage.breakdown.untested}%</span>
            </span>
          </div>
        </KpiCard>

        {/* Defect density */}
        <KpiCard label="Defect density" trend={quality.defectDensity.trend} trendDirection={quality.defectDensity.trendDirection}>
          <Metric value={quality.defectDensity.value.toString()} unit={quality.defectDensity.unit} />
          <p className="text-[13px] leading-[18px] text-[color:var(--p-text-2)] font-medium m-0">{quality.defectDensity.sub}</p>
          <span className="text-[11px] text-[color:var(--p-text-3)] bg-[color:var(--p-card-soft)] border border-[color:var(--p-border)] rounded-md px-2.5 py-1.5 mt-auto inline-flex items-center gap-1.5 flex-wrap">
            <Check className="w-2.5 h-2.5 text-[color:var(--p-pass)] shrink-0" strokeWidth={3} />
            <span dangerouslySetInnerHTML={{ __html: quality.defectDensity.benchmark.replace('1–5', '<b class="text-[color:var(--p-text-2)] font-[JetBrains_Mono] font-semibold">1–5</b>') }} />
          </span>
        </KpiCard>
      </div>
    </section>
  )
}

// ─── helpers ──────────────────────────────────────────────────────────

function KpiCard({
  label, trend, trendDirection, children,
}: {
  label: string
  trend: string
  trendDirection: 'up' | 'down-good' | 'flat'
  children: React.ReactNode
}) {
  const trendClass =
    trendDirection === 'flat'
      ? 'bg-[color:var(--p-card-soft)] text-[color:var(--p-text-3)] border-[color:var(--p-border)]'
      : 'bg-[color:var(--p-pass-bg)] text-[color:var(--p-pass)] border-[color:var(--p-pass-line)]'

  return (
    <article className="bg-[color:var(--p-card)] border border-[color:var(--p-border)] rounded-xl p-4 md:p-5 flex flex-col gap-2.5 min-h-[160px] md:min-h-[180px]">
      <div className="flex flex-wrap items-start justify-between gap-2.5">
        <span className="text-[10px] tracking-[0.1em] uppercase text-[color:var(--p-text-3)] font-bold">{label}</span>
        <span className={`font-[JetBrains_Mono] text-[11px] font-semibold inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded leading-none h-[22px] border whitespace-nowrap ${trendClass}`}>
          {trend}
        </span>
      </div>
      {children}
    </article>
  )
}

function Metric({ value, unit }: { value: string; unit: string }) {
  return (
    <p className="font-[JetBrains_Mono] text-[30px] leading-9 font-bold text-[color:var(--p-text-1)] tracking-[-0.02em] m-0 md:text-[36px] md:leading-[42px]">
      {value}<span className="text-base text-[color:var(--p-text-3)] font-medium ml-1 md:text-lg">{unit}</span>
    </p>
  )
}
