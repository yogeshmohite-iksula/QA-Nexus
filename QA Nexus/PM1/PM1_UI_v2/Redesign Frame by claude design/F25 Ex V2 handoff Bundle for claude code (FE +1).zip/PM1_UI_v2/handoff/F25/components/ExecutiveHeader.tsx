'use client'

import { useState } from 'react'
import { f25Demo } from '../data/canned-data'
import { Check, Download, RefreshCw } from 'lucide-react'

export function ExecutiveHeader() {
  const [tf, setTf] = useState<string>(f25Demo.activeTimeframe)
  const { release, scope, timeframes } = f25Demo

  return (
    <section
      data-canonical-section="release-header"
      role="banner"
      aria-label="Release header"
      className="flex flex-col gap-4"
    >
      <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-[color:var(--p-border)]">
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2 mb-1.5 text-[10px] tracking-[0.12em] uppercase font-bold text-[color:var(--p-text-3)]">
            <span className="font-[JetBrains_Mono] text-[9.5px] tracking-[0.04em] text-[color:var(--p-secondary)] bg-[color:var(--p-secondary-bg)] border border-[color:var(--p-secondary-line)] px-1.5 py-0.5 rounded-[3px] leading-none">
              Prove · Boardroom
            </span>
            <span>Release · Quality &amp; Value Snapshot</span>
          </div>
          <h1 className="font-[DM_Sans] text-[22px] leading-7 font-bold text-[color:var(--p-text-1)] tracking-[-0.01em] m-0 sm:text-[26px] sm:leading-8 lg:text-[30px] lg:leading-9">
            {release.title}
          </h1>
          <p className="text-[13px] leading-5 text-[color:var(--p-text-2)] mt-1.5">
            {release.sprintName} · Day <b className="text-[color:var(--p-text-1)] font-[JetBrains_Mono] font-semibold">{release.sprintDay}</b> of {release.sprintLength}{' '}
            <span className="text-[color:var(--p-text-4)] mx-2">·</span>
            Target ship <b className="text-[color:var(--p-text-1)] font-[JetBrains_Mono] font-semibold">{release.targetShipDate}</b>{' '}
            <span className="text-[color:var(--p-text-4)] mx-2">·</span>
            <b className="text-[color:var(--p-text-1)] font-[JetBrains_Mono] font-semibold">{release.daysRemaining} days</b> remaining
          </p>
        </div>
        <div className="flex flex-col items-end gap-2 shrink-0">
          <div
            role="status"
            aria-label={`${release.decision} decision`}
            className={`inline-flex items-center gap-2 px-[18px] py-2.5 rounded-lg font-[DM_Sans] text-lg font-bold leading-none border-2 tracking-[-0.01em] ${
              release.decision === 'GO'
                ? 'bg-[color:var(--p-pass-bg)] text-[color:var(--p-pass)] border-[color:var(--p-pass)]'
                : 'bg-[color:var(--p-fail-bg)] text-[color:var(--p-fail)] border-[color:var(--p-fail)]'
            }`}
          >
            <Check className="w-[18px] h-[18px]" strokeWidth={3.5} />
            {release.decision}
          </div>
          <span className="text-[11px] text-[color:var(--p-text-3)] font-[JetBrains_Mono] font-medium">
            Updated {release.updatedAt}
          </span>
        </div>
      </div>

      {/* Timeframe controls */}
      <div role="toolbar" aria-label="Timeframe and export" className="flex flex-wrap items-center gap-2 -mt-1">
        <div role="tablist" aria-label="Timeframe" className="inline-flex bg-[color:var(--p-card)] border border-[color:var(--p-border)] rounded-md p-0.5 h-[34px]">
          {timeframes.map((label) => {
            const isOn = tf === label
            return (
              <button
                key={label}
                role="tab"
                aria-selected={isOn}
                onClick={() => setTf(label)}
                className={`h-7 px-2.5 rounded text-[11.5px] font-semibold tracking-[0.02em] min-h-7 ${
                  isOn ? 'bg-[color:var(--p-secondary-bg)] text-[color:var(--p-secondary)]' : 'text-[color:var(--p-text-3)] hover:text-[color:var(--p-text-1)]'
                }`}
              >
                {label}
              </button>
            )
          })}
        </div>
        <button
          aria-label="Export dashboard"
          className="min-w-[44px] min-h-[44px] sm:w-[34px] sm:h-[34px] sm:min-w-0 sm:min-h-0 rounded-md bg-[color:var(--p-card)] border border-[color:var(--p-border)] text-[color:var(--p-text-3)] inline-flex items-center justify-center hover:text-[color:var(--p-text-1)] hover:bg-[color:var(--p-card-soft)] hover:border-[color:var(--p-border-strong)]"
        >
          <Download className="w-[13px] h-[13px]" strokeWidth={2} />
        </button>
        <button
          aria-label="Refresh data"
          className="min-w-[44px] min-h-[44px] sm:w-[34px] sm:h-[34px] sm:min-w-0 sm:min-h-0 rounded-md bg-[color:var(--p-card)] border border-[color:var(--p-border)] text-[color:var(--p-text-3)] inline-flex items-center justify-center hover:text-[color:var(--p-text-1)] hover:bg-[color:var(--p-card-soft)] hover:border-[color:var(--p-border-strong)]"
        >
          <RefreshCw className="w-[13px] h-[13px]" strokeWidth={2} />
        </button>
      </div>

      {/* Scope row */}
      <div role="region" aria-label="Release scope" className="flex flex-wrap items-center gap-0">
        <span className="inline-flex items-baseline gap-1.5 px-3 py-1.5 border-r border-[color:var(--p-border)] text-[12.5px] text-[color:var(--p-text-2)] first:pl-0 last:border-r-0">
          <span className="font-[JetBrains_Mono] font-semibold text-[color:var(--p-text-1)]">{scope.tickets}</span>tickets
        </span>
        <span className="inline-flex items-baseline gap-1.5 px-3 py-1.5 border-r border-[color:var(--p-border)] text-[12.5px] text-[color:var(--p-text-2)]">
          <span className="font-[JetBrains_Mono] font-semibold text-[color:var(--p-text-1)]">{scope.testCases}</span>test cases
        </span>
        <span className="inline-flex items-baseline gap-1.5 px-3 py-1.5 text-[12.5px] text-[color:var(--p-text-2)]">
          <span className="font-[JetBrains_Mono] font-semibold text-[color:var(--p-text-1)]">{scope.storiesDone}&nbsp;/&nbsp;{scope.storiesTotal}</span>stories ·{' '}
          <span className="font-[JetBrains_Mono] font-semibold text-[color:var(--p-primary)] ml-1">{scope.velocityPct}%</span>velocity
        </span>
        <div className="inline-flex flex-wrap items-center gap-2 mt-1.5 w-full md:ml-auto md:mt-0 md:w-auto">
          <span className="inline-flex items-center gap-1.5 text-[11.5px] font-semibold px-2 py-1 rounded-md leading-none h-6 border bg-[color:var(--p-pass-bg)] text-[color:var(--p-pass)] border-[color:var(--p-pass-line)]">
            <Check className="w-[11px] h-[11px]" strokeWidth={3} />
            Stable · last 50 runs <span className="font-[JetBrains_Mono] font-bold ml-1">{scope.last50RunsPassPct}%</span> pass
          </span>
          <span className="inline-flex items-center gap-1.5 text-[11.5px] font-semibold px-2 py-1 rounded-md leading-none h-6 border bg-[color:var(--p-warn-bg)] text-[color:var(--p-warn)] border-[color:var(--p-warn-line)]">
            <span className="font-[JetBrains_Mono] font-bold">{scope.openP0}</span> P0 ·{' '}
            <span className="font-[JetBrains_Mono] font-bold">{scope.openP1}</span> P1
            <span className="font-[JetBrains_Mono] font-bold text-[color:var(--p-pass)] ml-1">↓ {Math.abs(scope.p1DeltaThisWeek)}</span>
          </span>
        </div>
      </div>
    </section>
  )
}
