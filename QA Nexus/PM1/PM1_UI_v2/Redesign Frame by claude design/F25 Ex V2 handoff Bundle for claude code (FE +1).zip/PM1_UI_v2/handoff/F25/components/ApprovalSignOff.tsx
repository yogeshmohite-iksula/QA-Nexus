'use client'

import { f25Demo } from '../data/canned-data'
import { Check, Clock, Download } from 'lucide-react'

export function ApprovalSignOff() {
  const { approvals } = f25Demo

  return (
    <section
      data-canonical-section="approval"
      role="region"
      aria-label="Approval and sign-off"
      className="
        bg-[color:var(--p-card-soft)] border border-[color:var(--p-border)] rounded-xl
        p-[18px] md:p-5 lg:px-6
        grid grid-cols-1 md:grid-cols-3 xl:grid-cols-[1fr_1fr_1fr_auto]
        gap-[18px] md:gap-6
        items-start xl:items-center
      "
    >
      {approvals.map((a, i) => (
        <div
          key={a.label}
          className={`flex flex-col gap-1 pb-3.5 border-b border-[color:var(--p-border)] md:pb-0 md:border-b-0 ${
            i < approvals.length - 1 ? 'md:pr-[18px] md:border-r md:border-[color:var(--p-border)]' : ''
          } ${i === approvals.length - 1 ? 'xl:border-r-0 xl:pr-0' : ''}`}
        >
          <span className="text-[10px] tracking-[0.1em] uppercase text-[color:var(--p-text-3)] font-bold">{a.label}</span>
          <span className="flex items-center gap-2 text-sm font-semibold text-[color:var(--p-text-1)]">
            <Avatar tone={a.avatarTone} initials={a.initials} />
            {a.name}
          </span>
          <span className="text-[11px] text-[color:var(--p-text-3)]">{a.role}</span>
          <StatusPill status={a.status} statusDate={a.statusDate} />
        </div>
      ))}

      <div className="flex flex-row flex-wrap gap-2 items-center xl:flex-col xl:items-end">
        <button
          type="button"
          className="
            h-9 px-3.5 rounded-md border border-[color:var(--p-border-strong)]
            bg-[color:var(--p-card)] text-[color:var(--p-text-1)]
            text-[12.5px] font-semibold inline-flex items-center gap-1.5 leading-none
            min-h-9 hover:bg-[color:var(--p-card-soft)] hover:border-[color:var(--p-text-3)]
            md:min-h-11
          "
        >
          <Download className="w-3 h-3" strokeWidth={2} />
          Export PDF
        </button>
        <button
          type="button"
          className="
            h-9 px-3.5 rounded-md border border-[color:var(--p-primary)]
            bg-[color:var(--p-primary)] text-white
            text-[12.5px] font-semibold inline-flex items-center gap-1.5 leading-none
            min-h-9 hover:bg-[#0F766E] hover:border-[#0F766E]
            md:min-h-11
          "
        >
          <Check className="w-3 h-3" strokeWidth={2.4} />
          Approve release
        </button>
      </div>
    </section>
  )
}

function Avatar({ tone, initials }: { tone: 'green' | 'amber' | 'violet'; initials: string }) {
  const cls = {
    green: 'bg-[color:var(--p-primary-bg)] text-[color:var(--p-primary)] border-[color:var(--p-primary)]',
    amber: 'bg-[color:var(--p-warn-bg)] text-[color:var(--p-warn)] border-[color:var(--p-warn-line)]',
    violet: 'bg-[color:var(--p-secondary-bg)] text-[color:var(--p-secondary)] border-[color:var(--p-secondary-line)]',
  }[tone]
  return (
    <span className={`w-6 h-6 rounded-full inline-flex items-center justify-center font-[JetBrains_Mono] text-[9.5px] font-bold border shrink-0 ${cls}`}>
      {initials}
    </span>
  )
}

function StatusPill({ status, statusDate }: { status: 'approved' | 'pending'; statusDate: string }) {
  const isApproved = status === 'approved'
  return (
    <span
      className={`
        text-xs font-semibold inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md border leading-none h-[22px] w-fit mt-1
        ${isApproved
          ? 'bg-[color:var(--p-pass-bg)] text-[color:var(--p-pass)] border-[color:var(--p-pass-line)]'
          : 'bg-[color:var(--p-warn-bg)] text-[color:var(--p-warn)] border-[color:var(--p-warn-line)]'}
      `}
    >
      {isApproved
        ? <Check className="w-2.5 h-2.5" strokeWidth={3} />
        : <Clock className="w-2.5 h-2.5" strokeWidth={2.5} />}
      {isApproved ? `Approved · ${statusDate}` : `Pending · ${statusDate}`}
    </span>
  )
}
