'use client'

import { AdminShell } from '@/components/admin/admin-shell'
import { ExecutiveHeader } from './ExecutiveHeader'
import { RoiValueTile } from './RoiValueTile'
import { QualityPostureGrid } from './QualityPostureGrid'
import { RiskPostureGrid } from './RiskPostureGrid'
import { TrendsRow } from './TrendsRow'
import { RecommendationsPanel } from './RecommendationsPanel'
import { ApprovalSignOff } from './ApprovalSignOff'
import { FooterBand } from './FooterBand'
import './f25.css'

interface F25PageProps {
  /** Light = ivory boardroom, Dark = workspace canvas. Default: 'light' */
  theme?: 'light' | 'dark'
}

/**
 * F25 Executive Dashboard — root container.
 *
 * Hard Rule 14: wraps in AdminShell with locked Prove mode and
 * Executive Dashboard active in the ANALYSE section.
 *
 * Hard Rule 18 Part 1 TERTIARY: each region carries
 * data-canonical-section for diff-probe fallback.
 *
 * Hard Rule 15: all agent references go through AgentTooltip
 * (Composer/Curator/Sherlock); zero A1/A2/A4 in UI text.
 */
export function F25Page({ theme = 'light' }: F25PageProps) {
  return (
    <AdminShell
      activeNav="executive-dashboard"
      activeSection="analyse"
      mode="prove-locked"
    >
      <div
        className="f25-shell flex-1 overflow-y-auto"
        data-theme={theme}
        data-canonical-section="prove-canvas"
      >
        <div className="
          mx-auto flex flex-col gap-[18px] max-w-[1320px]
          px-[14px] pt-[18px] pb-[40px]
          sm:px-[18px] sm:pt-[22px] sm:pb-[48px]
          md:px-[24px] md:pt-[26px] md:pb-[56px] md:gap-[20px]
          lg:px-[32px] lg:pt-[28px]
        ">
          <ExecutiveHeader />
          <RoiValueTile />
          <QualityPostureGrid />
          <RiskPostureGrid />
          <TrendsRow />
          <RecommendationsPanel />
          <ApprovalSignOff />
          <FooterBand />
        </div>
      </div>
    </AdminShell>
  )
}
