# F25 Executive Dashboard — Handoff Bundle

**Generated:** 2026-05-18 · **Schema version:** 3 · **Design source:** `PM1_UI_v2/Redesign Frame by claude design/F25 Executive Dashboard v2.html` (and `… v2 -Dark-.html`)

## Destination

```
~/AI_Tester_Project/Project10-QA_Nexus/apps/web/components/executive/
```

Drop the `components/`, `data/`, and `spec/` subtrees from this bundle into that directory. Keep relative paths intact — imports are written assuming `~/components/executive/` is the package root.

---

## ⚠️ Read this first — as-built component names

The original F25 brief listed these components: `ExecutiveHeader · KpiStrip · DefectsTrendChart · TopClustersCard · RecentActivityFeed · QualityRisksCard · FooterBand`.

The design Yogesh **approved** evolved into a different set of regions. The bundle ships the **as-built** components — names match what's on screen, not the original brief. Mapping:

| Original brief name | As-built component | What changed |
|---|---|---|
| `ExecutiveHeader` | `ExecutiveHeader.tsx` | ✓ kept — title + Go/No-Go + timeframe + scope row |
| _(new)_ | `RoiValueTile.tsx` | 342% ROI hero + full formula breakdown + CTO quote |
| `KpiStrip` | `QualityPostureGrid.tsx` | 3-card grid (pass rate / coverage / defect density) instead of 5–6 stat cards |
| _(new)_ | `RiskPostureGrid.tsx` | 2-card grid (open defects pills / 5-of-5 readiness gates) |
| `DefectsTrendChart` | `TrendsRow.tsx` | 3 mini-charts (defect line · pass-rate bars · velocity bars) at 4-week granularity, not 30-day |
| `TopClustersCard` | — | Not in the approved design. Sherlock clustering lives on F20 / F22; F25 keeps it out of executive view. |
| `RecentActivityFeed` | — | Not in the approved design. F25 is "what shipped & how good was it," not a live activity feed. |
| `QualityRisksCard` | — | Risk surfacing folded into `RiskPostureGrid` (open defects pills + readiness gates) instead of a separate warnings card. |
| _(new)_ | `RecommendationsPanel.tsx` | Sherlock pre-ship narrative — 4 bullets w/ agent attribution |
| _(new)_ | `ApprovalSignOff.tsx` | 3-approver columns (QA Lead / Eng / PO) + Export PDF + Approve release CTAs |
| `FooterBand` | `FooterBand.tsx` | ✓ kept — last-updated + Sherlock/Composer credits + permalink |

If the FE+1 workflow expects the original names, **rename at import time** or rebrief the workflow rather than forcing the as-built design back into the original taxonomy.

---

## FE+1 frame-port workflow — which steps to skip

| Step | Action | This bundle |
|---|---|---|
| 1 | Read frame HTML + extract structure | **Done.** Use `spec/spec.json` instead of re-parsing the HTML. |
| 2 | Token reconciliation against `globals.css` | **Done.** Use `spec/tokens.md`. |
| 3 | Component decomposition + ARIA scaffold | **Done.** All 9 components are in `components/`. |
| 4 | Demo data extraction | **Done.** `data/canned-data.ts`. |
| 5 | AdminShell integration | See `spec/admin-shell-integration.md` — F25Page already wraps. |
| 6 | Responsive sweep (320 / 640 / 768 / 1024 / 1440) | Verify; classes are written mobile-first, but spot-check on real device. |
| 7 | Diff-probe (v2.2) | Run on first build. Expected: zero `MISSING`. Acceptable: `POTENTIAL_INVERSION` warns on the trend mini-charts (SVG-based, hard to diff). |

**Steps 1–4 are pre-done** — start at Step 5 (AdminShell wiring) when FE+1 picks this up.

---

## v2.2 diff-probe expectations

| Probe result | Verdict |
|---|---|
| `MISSING data-canonical-section` on any region | **Blocks merge.** Every region in `spec.json` declares one; check that it survived render. |
| `MISSING aria-label` on a region | **Blocks merge.** Same — declared in spec, must survive. |
| `POTENTIAL_INVERSION` on mini-chart axis labels | **Acceptable warn.** SVG `<text>` doesn't always diff cleanly; visual review the trends row. |
| `POTENTIAL_INVERSION` on Composer / Curator / Sherlock agent pills | **Acceptable warn.** The agent name + ⓘ tooltip is a single semantic unit; React renders the tooltip via Tippy or similar, not bare `data-tip`. |
| `EXTRA` for `RoiValueTile.tsx`, `RiskPostureGrid.tsx`, `RecommendationsPanel.tsx`, `ApprovalSignOff.tsx` | **Acceptable.** Listed in the as-built mapping above — these don't exist in the original brief. |

---

## Hard Rule references

- **Rule 14** — AdminShell parity. F25Page wraps in `<AdminShell>` with `activeNav="executive-dashboard"` and `mode="prove-locked"`. See `spec/admin-shell-integration.md`.
- **Rule 15** — Agent naming. All UI text uses Composer / Curator / Sherlock. The `AgentTooltip.tsx` micro-component renders the name + hover ⓘ. **Never** put `A1` / `A2` / `A4` in user-visible strings.
- **Rule 18 Part 1 TERTIARY** — Structural anchors. Every region declares `data-canonical-section="<slug>"` for the diff-probe fallback.

---

## Bundle layout

```
F25_handoff_bundle/
├── README.md                          ← this file
├── components/
│   ├── F25Page.tsx                    ← root, wraps AdminShell
│   ├── ExecutiveHeader.tsx            ← release header + Go/No-Go + timeframe + scope
│   ├── RoiValueTile.tsx               ← 342% ROI hero + formula + CTO quote
│   ├── QualityPostureGrid.tsx         ← 3 cards: pass rate / coverage / defect density
│   ├── RiskPostureGrid.tsx            ← 2 cards: open defects / readiness gates
│   ├── TrendsRow.tsx                  ← 3 mini-charts (defect / pass / velocity)
│   ├── RecommendationsPanel.tsx       ← Sherlock pre-ship bullets
│   ├── ApprovalSignOff.tsx            ← 3 approvers + Export PDF + Approve release
│   ├── FooterBand.tsx                 ← last-updated + agent credits + permalink
│   └── agents/
│       └── AgentTooltip.tsx           ← name + ⓘ hover, used everywhere
├── data/
│   └── canned-data.ts                 ← Iksula Returns demo content
└── spec/
    ├── spec.json                      ← structural anchors (schemaVersion 3)
    ├── tokens.md                      ← cross-ref to globals.css
    └── admin-shell-integration.md     ← Rule 14 compliance notes
```

---

## Quick start (FE+1)

```bash
# 1. Drop bundle contents
cp -r F25_handoff_bundle/components/* ~/AI_Tester_Project/Project10-QA_Nexus/apps/web/components/executive/
cp F25_handoff_bundle/data/canned-data.ts ~/AI_Tester_Project/Project10-QA_Nexus/apps/web/components/executive/data/

# 2. Wire the route
# in apps/web/app/(workspace)/executive-dashboard/page.tsx
# import { F25Page } from '@/components/executive/F25Page'
# export default function Page() { return <F25Page /> }

# 3. Verify ARIA anchors land on rendered output
# Run diff-probe v2.2 against the HTML source design.
```
