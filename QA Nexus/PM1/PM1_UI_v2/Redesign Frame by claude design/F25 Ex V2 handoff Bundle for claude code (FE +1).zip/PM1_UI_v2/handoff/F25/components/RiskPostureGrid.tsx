'use client'

import { f25Demo } from '../data/canned-data'
import { ArrowRight, Check } from 'lucide-react'

/**
 * Risk posture — 2 cards.
 *
 * Card 1: Open defects (P0/P1/P2/P3 pills with counts + target line + drill link).
 * Card 2: Release readiness gates (5-of-5 checklist + summary).
 */
export function RiskPostureGrid() {
  const { risk } = f25Demo
  const { openDefects: od, readinessGates: rg } = risk

  return (
    <section data-canonical-section="risk-posture" role="region" aria-label="Risk posture">
      <h2 className="font-[DM_Sans] text-[12.5px] leading-[18px] font-bold text-[color:var(--p-text-1)] m-0 mb-2.5 uppercase tracking-[0.08em] inline-flex items-center gap-2 flex-wrap">
        Risk posture
        <span className="font-[JetBrains_Mono] text-[10.5px] font-semibold text-[color:var(--p-text-3)] bg-[color:var(--p-card)] px-1.5 py-0.5 rounded-full leading-none border border-[color:var(--p-border)] normal-case tracking-normal">
          2 dimensions
        </span>
      </h2>

      <div className="grid grid-cols-1 gap-3 md:grid-cols-2 md:gap-4">
        {/* Open defects */}
        <article className="bg-[color:var(--p-card)] border border-[color:var(--p-border)] rounded-xl p-4 md:p-5 flex flex-col gap-2.5 min-h-[160px] md:min-h-[180px]">
          <div className="flex flex-wrap items-start justify-between gap-2.5">
            <span className="text-[10px] tracking-[0.1em] uppercase text-[color:var(--p-text-3)] font-bold">Open defects</span>
            <span className="font-[JetBrains_Mono] text-[11px] font-semibold inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded leading-none h-[22px] border whitespace-nowrap bg-[color:var(--p-pass-bg)] text-[color:var(--p-pass)] border-[color:var(--p-pass-line)]">
              {od.trend}
            </span>
          </div>
          <div className="bg-[color:var(--p-warn-bg)] border border-[color:var(--p-warn-line)] rounded-lg px-3 py-2.5 flex items-center gap-2 mt-1.5 flex-wrap">
            <DefPill tone="p0" count={od.counts.p0} />
            <DefPill tone="p1" count={od.counts.p1} />
            <DefPill tone="p2" count={od.counts.p2} />
            <DefPill tone="p3" count={od.counts.p3} />
          </div>
          <p className="text-[11.5px] text-[color:var(--p-text-2)] mt-auto leading-4">
            Target by ship: <b className="text-[color:var(--p-text-1)] font-semibold font-[JetBrains_Mono]">{od.target.p0Max} P0</b>
            <span className="text-[color:var(--p-text-4)] mx-1.5">·</span>
            <b className="text-[color:var(--p-text-1)] font-semibold font-[JetBrains_Mono]">≤ {od.target.p1Max} P1</b>
            <span className="text-[color:var(--p-pass)] font-bold ml-1.5">▼ on track</span>
          </p>
          <a href={od.drillLinkHref} className="text-[12px] text-[color:var(--p-secondary)] font-semibold no-underline inline-flex items-center gap-1 mt-1.5 hover:text-[color:var(--p-text-1)] min-h-6">
            {od.drillLinkLabel}
            <ArrowRight className="w-[11px] h-[11px]" strokeWidth={2.2} />
          </a>
        </article>

        {/* Readiness gates */}
        <article className="bg-[color:var(--p-card)] border border-[color:var(--p-border)] rounded-xl p-4 md:p-5 flex flex-col gap-2.5 min-h-[160px] md:min-h-[180px]">
          <div className="flex flex-wrap items-start justify-between gap-2.5">
            <span className="text-[10px] tracking-[0.1em] uppercase text-[color:var(--p-text-3)] font-bold">Release readiness gates</span>
            <span className="font-[JetBrains_Mono] text-[11px] font-semibold inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded leading-none h-[22px] border whitespace-nowrap bg-[color:var(--p-pass-bg)] text-[color:var(--p-pass)] border-[color:var(--p-pass-line)]">
              {rg.passed} of {rg.total} passed
            </span>
          </div>
          <div className="flex flex-col gap-1.5 mt-1.5">
            {rg.gates.map((g) => (
              <div key={g.name} className="flex items-center gap-2.5 text-[12.5px] text-[color:var(--p-text-1)] leading-[17px] flex-wrap">
                <span className="w-[18px] h-[18px] rounded-full bg-[color:var(--p-pass-bg)] text-[color:var(--p-pass)] border-[1.5px] border-[color:var(--p-pass)] inline-flex items-center justify-center shrink-0">
                  <Check className="w-[9px] h-[9px]" strokeWidth={3.6} />
                </span>
                <span className="font-semibold text-[color:var(--p-text-1)] flex-1 min-w-[120px]">{g.name}</span>
                <span className="text-[11px] text-[color:var(--p-text-3)] text-right">{g.detail}</span>
              </div>
            ))}
          </div>
          <span className="text-[12px] text-[color:var(--p-text-2)] bg-[color:var(--p-pass-bg)] border border-[color:var(--p-pass-line)] rounded-md px-2.5 py-1.5 mt-2 inline-flex items-center gap-1.5">
            <Check className="w-[11px] h-[11px] text-[color:var(--p-pass)] shrink-0" strokeWidth={3} />
            <span><b className="text-[color:var(--p-pass)] font-bold font-[JetBrains_Mono]">{rg.passed} of {rg.total} gates passed.</b> Release-ready.</span>
          </span>
        </article>
      </div>
    </section>
  )
}

function DefPill({ tone, count }: { tone: 'p0' | 'p1' | 'p2' | 'p3'; count: number }) {
  const cls = {
    p0: 'bg-[color:var(--p-fail-bg)] text-[color:var(--p-fail)] border-[color:var(--p-fail-line)]',
    p1: 'bg-[rgba(249,115,22,0.15)] text-[#FB923C] border-[rgba(249,115,22,0.40)] dark:bg-[#FFEDD5] dark:text-[#C2410C] dark:border-[#FDBA74]',
    p2: 'bg-[color:var(--p-warn-bg)] text-[color:var(--p-warn)] border-[color:var(--p-warn-line)]',
    p3: 'bg-[color:var(--p-card-soft)] text-[color:var(--p-text-3)] border-[color:var(--p-border)]',
  }[tone]
  return (
    <span className={`inline-flex items-center gap-1.5 font-[JetBrains_Mono] text-[13px] font-bold px-2.5 py-1.5 rounded-md leading-none h-[26px] border ${cls}`}>
      <span className="text-[15px] font-extrabold mr-px">{count}</span>
      <span className="text-[10px] tracking-[0.06em]">{tone.toUpperCase()}</span>
    </span>
  )
}
