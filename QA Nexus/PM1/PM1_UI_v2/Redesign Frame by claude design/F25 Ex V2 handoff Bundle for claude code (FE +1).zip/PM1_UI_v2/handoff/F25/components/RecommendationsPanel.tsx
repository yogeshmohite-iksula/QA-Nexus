'use client'

import { f25Demo } from '../data/canned-data'
import { AgentTooltip } from './agents/AgentTooltip'
import { Search } from 'lucide-react'

/**
 * Sherlock pre-ship recommendations panel.
 *
 * Header has the violet agent glyph + Sherlock name + version pill.
 * List items are styled with a violet bullet; positive signals are
 * tagged with green "+ Positive signal:" prefix.
 *
 * Curator mention inside the positive bullet uses AgentTooltip.
 */
export function RecommendationsPanel() {
  const { recommendations } = f25Demo

  return (
    <section
      data-canonical-section="recommendations"
      role="region"
      aria-labelledby="rec-heading"
      className="bg-[color:var(--p-secondary-bg)] border border-[color:var(--p-secondary-line)] rounded-xl p-[18px] md:p-[22px] flex flex-col gap-3"
    >
      <div className="flex flex-wrap items-center gap-2.5">
        <span aria-hidden="true" className="w-7 h-7 rounded-[7px] bg-[#DDD6FE] dark:bg-[rgba(167,139,250,0.20)] text-[color:var(--p-secondary)] border border-[#C4B5FD] dark:border-[rgba(167,139,250,0.40)] inline-flex items-center justify-center shrink-0">
          <Search className="w-3.5 h-3.5" strokeWidth={1.8} />
        </span>
        <h3 id="rec-heading" className="font-[DM_Sans] text-[15px] font-bold text-[color:var(--p-text-1)] m-0">
          Pre-ship recommendations
        </h3>
        <span className="font-[JetBrains_Mono] text-[9.5px] tracking-[0.04em] text-[color:var(--p-secondary)] bg-[#EDE9FE] dark:bg-[rgba(167,139,250,0.14)] border border-[#C4B5FD] dark:border-[rgba(167,139,250,0.40)] px-1.5 py-0.5 rounded-[3px] uppercase font-bold leading-none h-[18px] inline-flex items-center gap-1 ml-auto">
          <AgentTooltip name={recommendations.agent} className="text-[9.5px] tracking-[0.04em]" />
          · {recommendations.version}
        </span>
      </div>

      <ul className="flex flex-col gap-2 m-0 p-0 list-none">
        {recommendations.items.map((item, i) => (
          <li key={i} className="flex items-start gap-2.5 text-[13px] leading-[19px] text-[color:var(--p-text-1)]">
            <span className="w-1.5 h-1.5 rounded-full bg-[color:var(--p-secondary)] shrink-0 mt-[7px]" />
            <RecItem item={item} />
          </li>
        ))}
      </ul>
    </section>
  )
}

function RecItem({ item }: { item: { positive: boolean; body: string } }) {
  // Handle Curator mention in the positive bullet specially — render with AgentTooltip
  if (item.positive && item.body.includes('Curator')) {
    return (
      <span>
        <span className="text-[color:var(--p-pass)] font-semibold">+ Positive signal:</span>{' '}
        <AgentTooltip name="Curator" /> caught <b className="font-semibold">24 duplicate test cases</b>, preventing <b className="font-semibold">12 hours</b> of redundant test runs. Recommend expanding Curator across projects.
      </span>
    )
  }

  // Lightly mark up code fragments and bold "Recommendation:"-style cues
  return <span dangerouslySetInnerHTML={{ __html: markup(item.body) }} />
}

function markup(text: string): string {
  return text
    // Code chunks (lowercase_with_underscores, percentages with arrows, etc.)
    .replace(/(\bpayment_retry\b|\bcheckout_timeout\b|\badmin_cache_clear\b)/g,
      '<span class="font-[JetBrains_Mono] text-[12px] text-[color:var(--p-secondary)] bg-[rgba(124,58,237,0.10)] px-1 py-px rounded-[3px]">$1</span>')
    .replace(/(\b\d+%\s*→\s*\d+%)/g,
      '<span class="font-[JetBrains_Mono] text-[12px] text-[color:var(--p-secondary)] bg-[rgba(124,58,237,0.10)] px-1 py-px rounded-[3px]">$1</span>')
    // Bold key phrases
    .replace(/^(Flaky test stabilization complete\.|P1 admin_cache_clear occasionally hangs\.|Coverage gap\.)/,
      '<b class="text-[color:var(--p-text-1)] font-semibold">$1</b>')
    .replace(/(No further action\.|Does not block release\.|Patch ready for v2\.1\.)/g,
      '<b class="text-[color:var(--p-text-1)] font-semibold">$1</b>')
    .replace(/(\b1 hour before smoke test Apr 28\b|\blow\b(?= \.)|\b5% untested\b)/g,
      '<b class="text-[color:var(--p-text-1)] font-semibold">$1</b>')
}
