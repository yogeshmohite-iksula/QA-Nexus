'use client'

import { f25Demo } from '../data/canned-data'
import { AgentTooltip } from './agents/AgentTooltip'
import { TrendingUp, MessageSquare } from 'lucide-react'

export function RoiValueTile() {
  const { roi } = f25Demo
  const { formula } = roi

  return (
    <section
      data-canonical-section="roi-value"
      role="region"
      aria-label="Release ROI"
      className="
        bg-[color:var(--p-card)] border-2 border-[color:var(--p-primary)] rounded-[14px]
        p-5 md:p-6 lg:p-7
        grid grid-cols-1 lg:grid-cols-[1.4fr_1fr] gap-5 lg:gap-8
        shadow-[0_1px_0_0_rgba(13,148,136,0.06)]
      "
    >
      {/* Left — hero + formula */}
      <div className="flex flex-col gap-3 min-w-0">
        <div className="inline-flex items-center gap-2 text-[10px] tracking-[0.14em] uppercase text-[color:var(--p-primary)] font-bold">
          <TrendingUp className="w-[11px] h-[11px]" strokeWidth={2} />
          ROI · This release
        </div>
        <h2 className="font-[JetBrains_Mono] text-[42px] leading-[48px] font-bold text-[color:var(--p-text-1)] tracking-[-0.02em] m-0 break-words sm:text-[48px] sm:leading-[54px] lg:text-[54px] lg:leading-[60px]">
          <span className="text-[color:var(--p-primary)]">{roi.headlinePct}%</span> ROI
        </h2>
        <p className="text-sm leading-[21px] text-[color:var(--p-text-2)] m-0 max-w-[520px]">
          QA &amp; AI generated <b className="text-[color:var(--p-text-1)] font-semibold">{roi.headlinePct}% return</b> on AI infrastructure investment for this release. Conservative net is{' '}
          <b className="text-[color:var(--p-text-1)] font-semibold">{roi.conservativePct}%</b> (excluding indirect benefits).
        </p>

        {/* Formula breakdown */}
        <div
          aria-label="ROI formula breakdown"
          className="bg-[color:var(--p-card-soft)] border border-[color:var(--p-border)] rounded-lg px-3.5 py-3 font-[JetBrains_Mono] text-[11.5px] leading-[18px] text-[color:var(--p-text-2)] mt-1.5"
        >
          <FormulaRow label="Time saved" value={<>{formula.timeSavedHours} h <span className="text-[color:var(--p-text-3)] font-normal">({formula.timeSavedHumanDays} human-days)</span></>} />
          <FormulaRow label="Blended QA rate" value={`₹${formula.blendedQaRateInr.toLocaleString('en-IN')} / hour`} />
          <FormulaRow label="Time value" value={`₹${formula.timeValueInrLakh} L · ~$${Math.round(formula.timeValueUsd / 1000)}K`} />
          <FormulaRow label="+ Defects caught" value={`${formula.defectsCaught} (${formula.defectsPreProd} pre-prod · ${formula.defectsStaging} staging)`} sep />
          <FormulaRow label="+ Stage multiplier" value={`avg ${formula.stageMultiplier}× (PRD cost model)`} />
          <FormulaRow label="+ Cost avoided" value={`₹${formula.costAvoidedInrLakh} L · defect + rework`} />
          <FormulaRow label="= Total QA value" value={`₹${formula.totalQaValueInrLakh} L · ~$${(formula.totalQaValueUsd / 1000).toFixed(1)}K`} sep bold />
          <FormulaRow label="− AI infra cost" value={`₹${formula.aiInfraCostInrLakh} L · LLM + vector DB + compute`} />
          <FormulaRow label="= Net benefit" value={`₹${formula.netBenefitInrLakh} L · ~$${(formula.netBenefitUsd / 1000).toFixed(1)}K`} sep bold />
          <div className="flex items-center justify-between gap-3 py-0.5 text-[color:var(--p-primary)] font-bold text-[12.5px]">
            <span className="flex-1">= Net ROI</span>
            <span className="text-right">({formula.netBenefitInrLakh}L / {formula.aiInfraCostInrLakh}L) × 100 = {roi.conservativePct}%</span>
          </div>
        </div>
        <p className="text-[11px] leading-[15px] text-[color:var(--p-text-3)] italic mt-1.5">
          <b className="text-[color:var(--p-text-2)] font-semibold not-italic font-[JetBrains_Mono]">Note:</b> Headline {roi.headlinePct}% ROI includes indirect benefits (faster TTM, reduced hiring need, improved product quality perception — conservatively valued at{' '}
          <b className="text-[color:var(--p-text-2)] font-semibold not-italic font-[JetBrains_Mono]">₹{formula.indirectBenefitsInrLakh} L</b>).
        </p>
      </div>

      {/* Right — CTO quote */}
      <div className="flex flex-col justify-center gap-3.5 pt-5 border-t border-[color:var(--p-border)] lg:pt-0 lg:pl-7 lg:border-t-0 lg:border-l">
        <span className="inline-flex items-center gap-1.5 text-[10px] tracking-[0.12em] uppercase text-[color:var(--p-text-3)] font-bold">
          <MessageSquare className="w-[11px] h-[11px]" strokeWidth={2} />
          One-line CTO summary
        </span>
        <p className="text-sm leading-[21px] text-[color:var(--p-text-1)] font-medium italic m-0 lg:text-[15px] lg:leading-[22px]">
          &ldquo;AI-generated test cases cut authoring time by <b className="text-[color:var(--p-primary)] font-bold not-italic">50%</b>, caught{' '}
          <b className="text-[color:var(--p-primary)] font-bold not-italic">23 shipping defects</b> pre-release.{' '}
          <b className="text-[color:var(--p-primary)] font-bold not-italic">Justifies AI investment 3× over.</b>&rdquo;
        </p>
        <span className="text-[11px] text-[color:var(--p-text-3)] font-[JetBrains_Mono] mt-1">
          — <AgentTooltip name="Sherlock" /> narrative · approved by Akshay Panchal (QA Lead)
        </span>
      </div>
    </section>
  )
}

function FormulaRow({ label, value, sep, bold }: { label: string; value: React.ReactNode; sep?: boolean; bold?: boolean }) {
  return (
    <div
      className={`flex items-center justify-between gap-3 py-0.5 ${
        sep ? 'border-t border-[color:var(--p-border)] mt-1.5 pt-1.5' : ''
      } ${bold ? 'text-[color:var(--p-text-1)] font-bold' : ''}`}
    >
      <span className="flex-1">{label}</span>
      <span className="text-right text-[color:var(--p-text-1)] font-semibold">{value}</span>
    </div>
  )
}
