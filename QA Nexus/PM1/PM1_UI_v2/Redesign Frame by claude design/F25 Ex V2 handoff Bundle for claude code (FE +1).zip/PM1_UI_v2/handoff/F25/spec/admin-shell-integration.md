# AdminShell Integration — Hard Rule 14 compliance

## TL;DR

`F25Page.tsx` **must** wrap its content in `<AdminShell>`. The shell renders the left rail + top utility bar; F25 only contributes the `<main>` content area.

```tsx
import { AdminShell } from '@/components/admin/admin-shell'
import { ExecutiveHeader } from './ExecutiveHeader'
import { RoiValueTile } from './RoiValueTile'
// … other regions

export function F25Page() {
  return (
    <AdminShell
      activeNav="executive-dashboard"
      activeSection="analyse"
      mode="prove-locked"
    >
      <ExecutiveHeader />
      <RoiValueTile />
      <QualityPostureGrid />
      <RiskPostureGrid />
      <TrendsRow />
      <RecommendationsPanel />
      <ApprovalSignOff />
      <FooterBand />
    </AdminShell>
  )
}
```

## What the shell provides (do not redesign)

1. **Top utility bar** — 56px high, full width. Contains:
   - Mobile hamburger (`.menu-btn`)
   - Brand mark + word (`QA Nexus`)
   - Project pill (`Iksula Returns · main`)
   - Global search (`⌘K`)
   - Quick create / notifications / theme icon buttons
   - Mode toggle (Operate / Review / **Prove (locked)**)
   - User pill (avatar + name)

2. **Left rail** — 240px expanded, 64px collapsed. Contains:
   - Rail-collapse toggle (top)
   - Home + 5 collapsible sections: PLAN · AUTHOR · RUN · **ANALYSE** · GOVERN
   - Rail-foot (avatar + role)
   - localStorage persistence per section (`qa-nexus.shell.section-<name>-collapsed`)

## What F25 contributes

Everything inside `<main>` — the ivory (or dark) prove-mode content area. Eight regions as listed in `spec.json`.

## `<AdminShell>` props the F25 page uses

| Prop | Value for F25 | What it does |
|---|---|---|
| `activeNav` | `"executive-dashboard"` | Adds `.active` to the Executive Dashboard nav item; renders violet left-accent + secondary tone icon |
| `activeSection` | `"analyse"` | Forces ANALYSE section to render expanded on load, regardless of saved localStorage state. Doesn't write back. |
| `mode` | `"prove-locked"` | Locks the mode toggle to "Prove" with a lock-glyph icon; disables Operate / Review buttons. |

## Hard Rule 14 acceptance criteria

When you finish wiring F25:

- [ ] `<AdminShell>` is the outermost element in `F25Page.tsx` return value
- [ ] No part of F25's components renders a `.rail`, `.topbar`, `.menu-btn`, `.proj-pill`, `.global-search`, `.mode-toggle`, or `.user-pill` — those all come from the shell
- [ ] Active rail item highlights `Executive Dashboard` with the **violet left-accent** (secondary tone) — never primary teal
- [ ] ANALYSE section auto-expands on page load
- [ ] Mode toggle renders **Prove** with a lock icon; clicking Operate or Review is a no-op (or shows a tooltip explaining the lock)
- [ ] Mobile: rail becomes a slide-in drawer on hamburger click; sections still collapsible inside the drawer

## Rule 15 — Agent naming inside F25

Three places use agent names:

1. **RoiValueTile** — CTO quote attribution → `Sherlock narrative · approved by Akshay Panchal (QA Lead)`
2. **RecommendationsPanel** — header tag → `Sherlock v1.4`; one bullet → `Curator caught 24 duplicate test cases`
3. **FooterBand** — credit line → `Powered by Sherlock + Composer agents`

All three use the `<AgentTooltip name="Sherlock" />` micro-component (in `components/agents/AgentTooltip.tsx`) which renders the agent name + a hover ⓘ tooltip from `AGENT_TOOLTIPS` in `canned-data.ts`. **Never** put `A1`, `A2`, or `A4` in user-visible text.

## Rule 18 Part 1 TERTIARY — Structural anchors

Every top-level region in F25 has a `data-canonical-section` attribute matching the slug in `spec.json`:

| Region | Slug |
|---|---|
| ExecutiveHeader | `release-header` |
| RoiValueTile | `roi-value` |
| QualityPostureGrid | `quality-posture` |
| RiskPostureGrid | `risk-posture` |
| TrendsRow | `trends` |
| RecommendationsPanel | `recommendations` |
| ApprovalSignOff | `approval` |
| FooterBand | _(none — FooterBand is `<footer>` with `role="contentinfo"`)_ |

The v2.2 diff-probe uses these as a fallback anchor when ARIA labels or class names fail to match.
