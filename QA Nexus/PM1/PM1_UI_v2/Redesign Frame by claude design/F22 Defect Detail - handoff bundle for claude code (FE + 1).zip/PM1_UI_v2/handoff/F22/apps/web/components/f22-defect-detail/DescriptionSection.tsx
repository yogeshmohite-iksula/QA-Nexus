// Renders TipTap markdown-ish output. For the pilot we render the
// canned-data `description` string with minimal markdown handling
// (bold). BE+1 will replace with HTML from TipTap when wiring.
export function DescriptionSection({ markdown }: { markdown: string }) {
  const html = markdown
    .replace(/\*\*(.+?)\*\*/g, '<strong class="text-[color:var(--t1)] font-semibold">$1</strong>')
    .split(/\n\n+/)
    .map((p) => `<p class="mb-3 last:mb-0">${p}</p>`)
    .join('');
  return (
    <section role="region" aria-label="Defect description" data-canonical-section="description"
             className="space-y-2">
      <h2 className="font-mono text-[12px] uppercase tracking-[0.08em] text-[color:var(--t3)]">
        Description
      </h2>
      <div className="text-[14px] leading-[1.55] text-[color:var(--t2)]"
           dangerouslySetInnerHTML={{ __html: html }} />
    </section>
  );
}
