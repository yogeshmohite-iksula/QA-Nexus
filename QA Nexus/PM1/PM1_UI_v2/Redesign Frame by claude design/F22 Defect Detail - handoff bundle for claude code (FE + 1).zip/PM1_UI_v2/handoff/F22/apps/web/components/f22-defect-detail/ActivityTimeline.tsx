import { Sparkles, MessageSquare, GitCommit, UserCheck, Link2, RefreshCcw, Flag } from 'lucide-react';
import type { ActivityEvent, ActivityKind } from './types';
import { AgentName } from './agents/AgentName';

const KIND_META: Record<ActivityKind, { Icon: React.ComponentType<{className?:string}>; ring: string }> = {
  created:    { Icon: Flag,        ring: 'border-[color-mix(in_srgb,var(--info)_30%,transparent)] text-[color:var(--info)]' },
  agent:      { Icon: Sparkles,    ring: 'border-[color-mix(in_srgb,var(--secondary)_34%,transparent)] text-[color:var(--secondary)]' },
  comment:    { Icon: MessageSquare,ring:'border-[color:var(--border)] text-[color:var(--t3)]' },
  status:     { Icon: GitCommit,   ring: 'border-[color-mix(in_srgb,var(--warn)_34%,transparent)] text-[color:var(--warn)]' },
  assigned:   { Icon: UserCheck,   ring: 'border-[color-mix(in_srgb,var(--info)_30%,transparent)] text-[color:var(--info)]' },
  linked:     { Icon: Link2,       ring: 'border-[color:var(--border)] text-[color:var(--t3)]' },
  'jira-sync':{ Icon: RefreshCcw,  ring: 'border-[color-mix(in_srgb,var(--info)_30%,transparent)] text-[color:var(--info)]' },
};

function fmt(iso: string) {
  const d = new Date(iso);
  return d.toLocaleString('en-IN', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' });
}

export function ActivityTimeline({ events }: { events: ActivityEvent[] }) {
  return (
    <section role="region" aria-label="Activity timeline" data-canonical-section="activity-timeline"
             className="space-y-3">
      <h2 className="font-mono text-[12px] uppercase tracking-[0.08em] text-[color:var(--t3)]">
        Activity
      </h2>
      <ol role="feed" aria-busy="false"
          className="relative pl-7 space-y-3 before:absolute before:left-3 before:top-2 before:bottom-2 before:w-px before:bg-[color:var(--border)]">
        {events.map((ev) => {
          const meta = KIND_META[ev.kind];
          const Icon = meta.Icon;
          const isAgent = ev.kind === 'agent';
          const agentCode =
            ev.actor.toLowerCase() === 'sherlock' ? 'sherlock' :
            ev.actor.toLowerCase() === 'curator'  ? 'curator'  :
            ev.actor.toLowerCase() === 'composer' ? 'composer' : null;

          return (
            <li key={ev.id} className="relative">
              <span className={`absolute -left-[26px] top-0.5 inline-flex h-5 w-5 items-center justify-center rounded-full bg-[color:var(--surface)] border ${meta.ring}`}
                    aria-hidden="true">
                <Icon className="h-3 w-3" />
              </span>
              <div className="text-[12.5px] leading-[1.55] text-[color:var(--t2)]">
                {isAgent && agentCode
                  ? <AgentName code={agentCode as 'sherlock'|'curator'|'composer'} />
                  : <b className="text-[color:var(--t1)] font-semibold">{ev.actor}</b>}
                <span className="ml-1.5">{ev.text}</span>
                <time dateTime={ev.at} className="ml-2 font-mono text-[10.5px] text-[color:var(--t4)]">{fmt(ev.at)}</time>
              </div>
            </li>
          );
        })}
      </ol>
    </section>
  );
}
