'use client';
import { useState } from 'react';
import { SlidersHorizontal, X, ExternalLink } from 'lucide-react';
import { Sheet, SheetContent, SheetTitle } from '@/components/ui/sheet';
import type { RightRailMeta } from './types';

function Avatar({ name, initials, size = 'md' }: { name: string; initials: string; size?: 'sm' | 'md' }) {
  const dim = size === 'sm' ? 'h-5 w-5 text-[9px]' : 'h-7 w-7 text-[11px]';
  return (
    <span className={`${dim} inline-flex shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-[color:var(--primary)] to-[color:var(--secondary)] font-mono font-bold text-[color:var(--bg)]`}
          aria-label={name}>
      {initials}
    </span>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <span className="font-mono text-[10px] uppercase tracking-[0.08em] text-[color:var(--t3)] font-semibold">
      {children}
    </span>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5 py-2.5 border-b border-[color:var(--border)] last:border-b-0">
      <Label>{label}</Label>
      <div className="text-[13px] text-[color:var(--t1)]">{children}</div>
    </div>
  );
}

function Tag({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded-sm border border-[color:var(--border)] bg-[color:var(--surface-2)] text-[color:var(--t2)] text-[11px] font-mono">
      {children}
    </span>
  );
}

function Body({ meta }: { meta: RightRailMeta }) {
  return (
    <div className="px-4 py-2">
      <Row label="Status">
        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md border border-[color:var(--border)] bg-[color:var(--surface-2)]">
          <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--warn)]" aria-hidden="true" />
          <span className="text-[12px] font-medium">{meta.status}</span>
        </span>
        <div className="mt-2 flex flex-wrap gap-1">
          {meta.allowedTransitions.map((t) => (
            <button key={t} type="button"
                    className="min-h-[44px] px-3 rounded-md border border-[color:var(--border)] bg-transparent text-[12px] text-[color:var(--t2)] hover:bg-[color:var(--surface-2)] hover:text-[color:var(--t1)]">
              → {t}
            </button>
          ))}
        </div>
      </Row>

      <Row label="Assignee">
        <span className="inline-flex items-center gap-2">
          <Avatar name={meta.assignee.name} initials={meta.assignee.initials} />
          <span className="font-medium">{meta.assignee.name}</span>
        </span>
      </Row>

      <Row label="Reporter">
        <span className="inline-flex items-center gap-2">
          <Avatar name={meta.reporter.name} initials={meta.reporter.initials} />
          <span className="font-medium">{meta.reporter.name}</span>
        </span>
      </Row>

      <Row label="Severity / Priority">
        <span className="flex items-center gap-2 text-[12.5px]">
          <span className="inline-flex items-center px-2 py-0.5 rounded-md border font-mono text-[10.5px] font-bold
                           bg-[color-mix(in_srgb,var(--fail)_14%,transparent)] text-[color:var(--fail)]
                           border-[color-mix(in_srgb,var(--fail)_34%,transparent)]">
            {meta.severity}
          </span>
          <span className="text-[color:var(--t3)]">·</span>
          <span className="text-[color:var(--t1)] font-medium">{meta.priority}</span>
        </span>
      </Row>

      <Row label="Sprint">
        <span className="inline-flex items-center px-2 py-0.5 rounded-md border border-[color-mix(in_srgb,var(--secondary)_30%,transparent)] bg-[color-mix(in_srgb,var(--secondary)_12%,transparent)] text-[color:var(--secondary)] text-[12px] font-mono">
          {meta.sprint}
        </span>
      </Row>

      <Row label="Environment">
        <Tag>{meta.environment}</Tag>
      </Row>

      <Row label="Tags">
        <div className="flex flex-wrap gap-1.5">
          {meta.tags.map((t) => (<Tag key={t}>#{t}</Tag>))}
        </div>
      </Row>

      <Row label="Linked Jira issue">
        {meta.jiraIssue.synced ? (
          <a href={`https://iksula.atlassian.net/browse/${meta.jiraIssue.key}`}
             target="_blank" rel="noreferrer"
             className="inline-flex items-center gap-2 text-[color:var(--secondary)] hover:underline">
            <span className="font-mono text-[12px] font-semibold">{meta.jiraIssue.key}</span>
            <span className="text-[color:var(--t3)]">·</span>
            <span className="text-[12px] text-[color:var(--t2)]">{meta.jiraIssue.status}</span>
            <ExternalLink className="h-3 w-3" aria-hidden="true" />
          </a>
        ) : (
          <span className="text-[color:var(--t3)] text-[12px]">Not synced</span>
        )}
      </Row>

      <Row label="Watchers">
        <div className="flex flex-wrap items-center gap-2">
          {meta.watchers.map((w) => (
            <span key={w.initials} className="inline-flex items-center gap-1.5 text-[12px] text-[color:var(--t2)]">
              <Avatar name={w.name} initials={w.initials} size="sm" />
              <span>{w.name}</span>
            </span>
          ))}
        </div>
      </Row>
    </div>
  );
}

export function RightRail({ meta }: { meta: RightRailMeta }) {
  const [open, setOpen] = useState(false);

  return (
    <>
      {/* Mobile: button + Sheet drawer */}
      <div className="lg:hidden">
        <button type="button" onClick={() => setOpen(true)}
                className="inline-flex items-center gap-1.5 min-h-[44px] px-4 rounded-md border border-[color:var(--border)] bg-[color:var(--surface-2)] text-[13px] font-medium">
          <SlidersHorizontal className="h-3.5 w-3.5" />
          Defect metadata
        </button>
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetContent side="right"
            className="w-full sm:max-w-md bg-[color:var(--surface)] border-l border-[color:var(--border)]"
            aria-label="Defect metadata and workflow">
            <SheetTitle className="px-4 pt-4 font-mono text-[12px] uppercase tracking-[0.08em] text-[color:var(--t3)]">
              Defect metadata
            </SheetTitle>
            <button type="button" onClick={() => setOpen(false)} aria-label="Close drawer"
                    className="absolute top-3 right-3 inline-flex h-11 w-11 items-center justify-center rounded-md text-[color:var(--t3)] hover:bg-[color:var(--surface-2)] hover:text-[color:var(--t1)]">
              <X className="h-4 w-4" />
            </button>
            <Body meta={meta} />
          </SheetContent>
        </Sheet>
      </div>

      {/* Desktop: sticky right column */}
      <aside role="complementary" aria-label="Defect metadata and workflow"
             data-canonical-section="right-rail"
             className="hidden lg:block lg:sticky lg:top-20 lg:self-start rounded-lg border border-[color:var(--border)] bg-[color:var(--surface)]">
        <header className="px-4 py-3 border-b border-[color:var(--border)]">
          <h2 className="font-mono text-[12px] uppercase tracking-[0.08em] text-[color:var(--t3)]">
            Defect metadata
          </h2>
        </header>
        <Body meta={meta} />
      </aside>
    </>
  );
}
