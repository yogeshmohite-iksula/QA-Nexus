'use client';
import { useState } from 'react';
import { AlertTriangle, X } from 'lucide-react';
import { AgentName } from './agents/AgentName';

export function AmberBanner({ confidence }: { confidence: number }) {
  const [dismissed, setDismissed] = useState(false);
  if (dismissed) return null;
  return (
    <div role="alert" aria-live="polite"
         aria-label={`Needs human review — Sherlock confidence ${confidence.toFixed(2)}`}
         data-canonical-section="amber-banner"
         className="flex items-start gap-3 rounded-md border border-[color-mix(in_srgb,var(--warn)_34%,transparent)] bg-[color-mix(in_srgb,var(--warn)_12%,transparent)] px-4 py-3">
      <AlertTriangle className="h-4 w-4 mt-0.5 text-[color:var(--warn)] flex-none" aria-hidden="true" />
      <div className="flex-1 min-w-0 text-[13px] leading-5 text-[color:var(--t1)]">
        <AgentName code="sherlock" /> confidence{' '}
        <span className="font-mono font-semibold">{confidence.toFixed(2)}</span> — RCA may be
        incomplete, review before triage.
      </div>
      <button type="button" onClick={() => setDismissed(true)} aria-label="Dismiss banner"
              className="inline-flex h-11 w-11 items-center justify-center rounded-md text-[color:var(--t3)] hover:bg-[color:var(--surface-2)] hover:text-[color:var(--t1)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[color:var(--secondary)]">
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}
