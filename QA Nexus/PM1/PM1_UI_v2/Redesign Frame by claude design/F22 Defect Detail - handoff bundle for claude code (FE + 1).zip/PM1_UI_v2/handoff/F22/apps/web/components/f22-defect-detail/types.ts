// Types for F22 Defect Detail canned data.

export type Severity = 'P0' | 'P1' | 'P2' | 'P3';
export type Environment = 'local' | 'staging' | 'prod';

export interface Defect {
  id: string;
  title: string;
  severity: Severity;
  status: string;
  reporter: string;
  assignee: string;
  reportedAt: string;     // ISO 8601
  environment: Environment;
  sprint: string;
  tags: string[];
  jiraKey: string;
  testCase: string;
  requirement: string;
  confidence: number;     // 0..1
}

export interface RcaLayer {
  id: 'layer1' | 'layer2' | 'layer3' | 'layer4';
  title: string;
  confidence: number;     // 0..1
  defaultExpanded: boolean;
  body: string;
  code?: string;
  codeLanguage?: string;
  logLineRef?: string;
}

export interface Comment {
  id: string;
  author: string;
  role: string;
  at: string;
  body: string;
}

export type ActivityKind =
  | 'created' | 'agent' | 'comment' | 'status'
  | 'assigned' | 'linked' | 'jira-sync';

export interface ActivityEvent {
  id: string;
  kind: ActivityKind;
  at: string;
  actor: string;
  text: string;
}

export interface LinkedEntity {
  kind: 'test-case' | 'requirement' | 'defect';
  id: string;
  title: string;
  status: string;
}

export interface RightRailMeta {
  status: string;
  allowedTransitions: string[];
  assignee: { name: string; initials: string };
  reporter: { name: string; initials: string };
  severity: Severity;
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  sprint: string;
  environment: Environment;
  tags: string[];
  jiraIssue: { key: string; status: string; synced: boolean };
  watchers: { name: string; initials: string }[];
}

export type AgentCode = 'composer' | 'curator' | 'sherlock';
