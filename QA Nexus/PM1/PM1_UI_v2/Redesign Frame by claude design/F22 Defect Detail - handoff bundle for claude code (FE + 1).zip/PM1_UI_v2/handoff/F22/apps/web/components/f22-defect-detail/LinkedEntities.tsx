import { FileCheck, FileText, AlertOctagon } from 'lucide-react';
import type { LinkedEntity } from './types';

const ICONS = { 'test-case': FileCheck, 'requirement': FileText, 'defect': AlertOctagon };

export function LinkedEntities({ entities }: { entities: LinkedEntity[] }) {
  return (
    <section role="region" aria-label="Linked entities" data-canonical-section="linked-entities"
             className="space-y-3">
      <h2 className="font-mono text-[12px] uppercase tracking-[0.08em] text-[color:var(--t3)]">
        Linked entities
      </h2>
      <ul className="grid grid-cols-1 gap-2 md:grid-cols-2">
        {entities.map((e) => {
          const Icon = ICONS[e.kind];
          return (
            <li key={e.id}>
              <a href={`/${e.kind === 'test-case' ? 'test-cases' : e.kind === 'requirement' ? 'requirements' : 'defects'}/${e.id}`}
                 className="flex items-start gap-3 rounded-md border border-[color:var(--border)] bg-[color:var(--surface)] p-3 hover:border-[color:var(--border-strong)] hover:bg-[color:var(--surface-2)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[color:var(--secondary)] min-h-[64px]">
                <Icon className="h-4 w-4 mt-0.5 text-[color:var(--t3)] flex-none" aria-hidden="true" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline gap-2 flex-wrap">
                    <span className="font-mono text-[12px] text-[color:var(--secondary)] font-semibold">{e.id}</span>
                    <span className="text-[13px] text-[color:var(--t1)] font-medium">{e.title}</span>
                  </div>
                  <div className="font-mono text-[10.5px] text-[color:var(--t3)] mt-0.5">{e.status}</div>
                </div>
              </a>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
