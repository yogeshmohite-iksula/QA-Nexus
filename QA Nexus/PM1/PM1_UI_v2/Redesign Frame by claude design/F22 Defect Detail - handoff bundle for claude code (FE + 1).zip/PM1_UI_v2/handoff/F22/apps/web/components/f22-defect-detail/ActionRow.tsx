'use client';
import { useState } from 'react';
import { RotateCw, ExternalLink, Link2, UserPlus, MoreHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { Defect } from './types';

export function ActionRow({ defect }: { defect: Defect }) {
  const [moreOpen, setMoreOpen] = useState(false);
  void defect;
  // All buttons ≥ 44×44 px hit area (h-11 = 44 on Tailwind default scale).
  const cls = "inline-flex items-center gap-1.5 h-11 px-4 rounded-md border border-[color:var(--border)] bg-[color:var(--surface-2)] text-[color:var(--t1)] text-[13px] font-medium hover:bg-[color:var(--surface-3)] hover:border-[color:var(--border-strong)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[color:var(--secondary)]";
  return (
    <section role="toolbar" aria-label="Defect actions" data-canonical-section="action-row"
             className="flex flex-wrap gap-2">
      <button className={cls} type="button"><RotateCw className="h-3.5 w-3.5" />Reopen</button>
      <button className={cls} type="button"><ExternalLink className="h-3.5 w-3.5" />Convert to Jira</button>
      <button className={cls + ' hidden sm:inline-flex'} type="button"><Link2 className="h-3.5 w-3.5" />Link Test Case</button>
      <button className={cls + ' hidden sm:inline-flex'} type="button"><UserPlus className="h-3.5 w-3.5" />Assign…</button>
      <button className={cls} type="button" aria-haspopup="menu" aria-expanded={moreOpen}
              onClick={() => setMoreOpen((v) => !v)}>
        <MoreHorizontal className="h-3.5 w-3.5" />More
      </button>
    </section>
  );
}
