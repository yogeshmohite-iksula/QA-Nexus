# Path rename required after extracting the zip

The sandbox filesystem does not allow `(` `)` `[` `]` in folder names,
so two paths in this bundle are slightly mangled.

**Before drop-in to your repo, rename:**

| Bundle path | Repo path |
|---|---|
| `apps/web/src/app/-app-/` | `apps/web/src/app/(app)/` |
| `apps/web/src/app/-app-/defects/-id-/` | `apps/web/src/app/(app)/defects/[id]/` |

One-shot fix (from inside the unzipped bundle root):

```bash
mv "apps/web/src/app/-app-/defects/-id-" "apps/web/src/app/-app-/[id-tmp]"
mv "apps/web/src/app/-app-/defects/[id-tmp]" "apps/web/src/app/-app-/defects/[id]"
mv "apps/web/src/app/-app-" "apps/web/src/app/(app)"
```

Or, on macOS where shell quoting can be tetchy with brackets, simpler:

```bash
cd apps/web/src/app
mv -- -app- '(app)'
cd '(app)/defects'
mv -- -id- '[id]'
```

After rename you should have:

```
apps/web/src/app/(app)/defects/[id]/page.tsx
```

— which is the Next.js App Router convention the route group and
dynamic segment require.

Everything else in the bundle uses normal filenames.
