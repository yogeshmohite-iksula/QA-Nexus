'use client';
import { useEffect, useState, useCallback } from 'react';
import { RcaLayer } from './RcaLayer';
import { AgentName } from './agents/AgentName';
import type { RcaLayer as RcaLayerType } from './types';

const STORAGE_KEY = 'qa-nexus.f22.rca.expanded-layers';

export function RcaAccordion({ layers }: { layers: RcaLayerType[] }) {
  const [expanded, setExpanded] = useState<Set<string>>(() => new Set());

  // Hydrate state: localStorage saved set ∪ defaults ∪ ?rca=N deep-link
  useEffect(() => {
    const initial = new Set<string>();
    layers.forEach((l) => { if (l.defaultExpanded) initial.add(l.id); });
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const arr = JSON.parse(raw) as string[];
        if (Array.isArray(arr)) arr.forEach((id) => initial.add(id));
      }
    } catch { /* ignore */ }
    const url = new URL(window.location.href);
    const deep = url.searchParams.get('rca');
    if (deep) {
      const id = `layer${parseInt(deep, 10)}`;
      if (layers.some((l) => l.id === id)) initial.add(id);
    }
    setExpanded(initial);
  }, [layers]);

  const toggle = useCallback((id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify([...next])); } catch { /* ignore */ }
      return next;
    });
  }, []);

  return (
    <section role="region" data-canonical-section="rca-accordion"
             aria-label="Sherlock RCA — 4-layer root cause analysis"
             className="space-y-3">
      <div className="flex items-center gap-2 flex-wrap">
        <h2 className="font-mono text-[12px] uppercase tracking-[0.08em] text-[color:var(--t3)]">
          Root Cause Analysis
        </h2>
        <span className="text-[12px] text-[color:var(--t3)]">·</span>
        <AgentName code="sherlock" />
        <span className="ml-auto font-mono text-[10.5px] uppercase tracking-[0.06em] text-[color:var(--t3)]">
          {layers.length} layers · {expanded.size} expanded
        </span>
      </div>

      <div className="rounded-lg border border-[color:var(--border)] bg-[color:var(--surface)] divide-y divide-[color:var(--border)] overflow-hidden">
        {layers.map((layer, idx) => (
          <RcaLayer
            key={layer.id}
            layer={layer}
            index={idx + 1}
            expanded={expanded.has(layer.id)}
            onToggle={() => toggle(layer.id)}
          />
        ))}
      </div>
    </section>
  );
}
