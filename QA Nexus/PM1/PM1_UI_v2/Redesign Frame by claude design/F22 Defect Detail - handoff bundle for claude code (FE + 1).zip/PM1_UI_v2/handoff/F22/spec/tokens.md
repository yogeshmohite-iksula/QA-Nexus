# F22 Token Map (Tailwind v4 CSS-first)

All colors in this bundle are CSS variables defined in
`apps/web/src/app/globals.css`. No `@theme` extensions, no hex literals.

## Required CSS vars

| Token | Used for |
|---|---|
| `--bg` | Page background (set by AdminShell) |
| `--surface` | Cards, accordion shell, drawer |
| `--surface-2` | Action buttons, sprint pills, banners |
| `--surface-3` | Hover state for surface-2 |
| `--border` | Default border |
| `--border-strong` | Hover border |
| `--text` / `--t1` | Primary text |
| `--t2` | Body / secondary text |
| `--t3` | Metadata labels, timestamps, helper |
| `--t4` | Faint text, dividers |
| `--primary` | Indigo brand — avatar gradient start |
| `--secondary` | Cyan accent — agent names, links, focus ring |
| `--pass` | Success — high-confidence chip |
| `--fail` | Critical — severity P0/P1, error |
| `--warn` | Warning — amber banner, status pill dot, low-confidence chip |
| `--info` | Info — Jira sync, status events |
| `--rail-w` / `--topbar-h` / `--tap` | Shell geometry (do not override) |

## Conventions

- Use `color-mix(in srgb, var(--X) NN%, transparent)` for tints — never hard-code rgba/hex.
- Min tap target `44px` enforced via Tailwind `h-11` or `min-h-[44px]`.
- Focus ring: `focus-visible:outline focus-visible:outline-2 focus-visible:outline-[color:var(--secondary)]` on every interactive element.
- Severity badges (P0/P1/P2/P3) and status pill use the same tint formula as the v2 HTML — see `DefectHeader.tsx`.

## Banned

- No Material Design 3 tokens (`tertiary`, `error`, `primaryContainer`).
- No hardcoded hex / named colors anywhere in TSX or CSS.
- No `@theme { ... }` extensions for F22 — the page consumes existing vars.
