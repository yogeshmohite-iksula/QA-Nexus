import { DefectHeader } from './DefectHeader';
import { ActionRow } from './ActionRow';
import { AmberBanner } from './AmberBanner';
import { DescriptionSection } from './DescriptionSection';
import { ReproductionSteps } from './ReproductionSteps';
import { RcaAccordion } from './RcaAccordion';
import { ActivityTimeline } from './ActivityTimeline';
import { LinkedEntities } from './LinkedEntities';
import { RightRail } from './RightRail';
import type { Defect, RcaLayer, Comment, ActivityEvent, LinkedEntity, RightRailMeta } from './types';

interface Props {
  defect: Defect;
  rcaLayers: RcaLayer[];
  comments: Comment[];
  activity: ActivityEvent[];
  linkedEntities: LinkedEntity[];
  rightRail: RightRailMeta;
  description: string;
  reproductionSteps: string[];
}

export function F22DefectDetail(props: Props) {
  const { defect, rcaLayers, activity, linkedEntities, rightRail, description, reproductionSteps } = props;
  const showAmberBanner = defect.confidence < 0.5;

  return (
    <div className="mx-auto w-full max-w-screen-2xl">
      {/* Two-column grid: main 70% / rail 30% on desktop, stacked on mobile */}
      <div className="grid grid-cols-1 gap-6 px-4 py-6 md:px-6 lg:grid-cols-[minmax(0,7fr)_minmax(0,3fr)] lg:gap-8 lg:px-8 lg:py-8">
        <main className="min-w-0 space-y-6">
          <nav role="navigation" aria-label="Breadcrumb" data-canonical-section="breadcrumb"
               className="text-[11px] font-mono uppercase tracking-[0.08em] text-[color:var(--t3)]">
            <a href="/defects" className="hover:text-[color:var(--t2)]">Defects</a>
            <span className="mx-1.5 text-[color:var(--t4)]">›</span>
            <span className="text-[color:var(--t2)]">{defect.id}</span>
          </nav>

          <DefectHeader defect={defect} />
          <ActionRow defect={defect} />
          {showAmberBanner ? <AmberBanner confidence={defect.confidence} /> : null}
          <DescriptionSection markdown={description} />
          <ReproductionSteps steps={reproductionSteps} />
          <RcaAccordion layers={rcaLayers} />
          <ActivityTimeline events={activity} />
          <LinkedEntities entities={linkedEntities} />
        </main>

        <RightRail meta={rightRail} />
      </div>
    </div>
  );
}
