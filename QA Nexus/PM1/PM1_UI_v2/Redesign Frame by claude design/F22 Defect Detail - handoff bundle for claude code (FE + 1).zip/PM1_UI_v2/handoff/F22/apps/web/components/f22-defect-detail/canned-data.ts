// F22 Defect Detail — canned data (verbatim from design brief)
// Iksula Returns / RET project · Sprint 42 · Day 9 of 14
// Do NOT mutate values — frame-port v2.2 diff-probe asserts every
// user-visible string traces back to this file.

import type {
  Defect, RcaLayer, Comment, ActivityEvent, LinkedEntity, RightRailMeta,
} from './types';

export const defect: Defect = {
  id: 'DEF-318',
  title: 'Refund webhook returns 503 under load',
  severity: 'P1',
  status: 'Open · Triage',
  reporter: 'Kishor Kadam',
  assignee: 'Nadim Siddiqui',
  reportedAt: '2026-05-19T08:14:00+05:30',
  environment: 'staging',
  sprint: 'RET Sprint 42',
  tags: ['refund', 'webhook', 'race-condition'],
  jiraKey: 'RET-318',
  testCase: 'TC-RET-142',
  requirement: 'RET-87',
  confidence: 0.42, // < 0.5 → amber "Needs human review" banner
};

export const rcaLayers: RcaLayer[] = [
  {
    id: 'layer1',
    title: 'Symptom',
    confidence: 0.92,
    defaultExpanded: true,
    body: 'Refund webhook endpoint returns HTTP 503 Service Unavailable when called >50 times per minute. Customer-facing impact: refund confirmation emails fail to dispatch.',
  },
  {
    id: 'layer2',
    title: 'Proximate cause',
    confidence: 0.78,
    defaultExpanded: false,
    body: 'Connection pool exhaustion. PaymentService maintains 10 connections to PostgreSQL; under load the pool stays saturated and new requests time out.',
  },
  {
    id: 'layer3',
    title: 'Underlying cause',
    confidence: 0.55,
    defaultExpanded: false,
    body: 'Refund flow opens a transaction that spans an external webhook call (mean 1.8s). Transaction holds the DB connection for the full webhook duration, multiplying pool pressure by ~20x relative to a pure-DB transaction.',
  },
  {
    id: 'layer4',
    title: 'Recommended fix',
    confidence: 0.42, // drives amber banner
    defaultExpanded: false,
    body: 'Restructure: (1) commit DB transaction BEFORE webhook call, (2) implement webhook idempotency key, (3) move webhook dispatch to async job queue. Note: Sherlock confidence is low because the codebase has 3 different webhook patterns and the right pattern for refund flow needs human input.',
    code: `// Current (problematic):
await db.transaction(async (tx) => {
  await tx.update(refunds).set({ status: 'processing' });
  await webhookClient.notify(refund.url);  // ← holds tx open
  await tx.update(refunds).set({ status: 'completed' });
});

// Recommended:
await db.transaction(async (tx) => {
  await tx.update(refunds).set({ status: 'queued' });
});
await jobQueue.enqueue('refund.webhook', { refundId, idempotencyKey });`,
    codeLanguage: 'typescript',
  },
];

export const reproductionSteps: string[] = [
  'Log in to staging as a QA Engineer (kishor.kadam@iksula.com).',
  'Open Iksula Returns admin → Refunds → seed 60 pending refunds via the seed-bulk-refunds script.',
  'Trigger the refund-webhook flow by clicking "Process all pending" (or POST /api/refunds/process-all).',
  'Observe the request count climbing >50/minute against /api/refunds/webhook/notify.',
  'After ~12s, new requests start returning HTTP 503 Service Unavailable.',
  'Customer side: refund confirmation emails for affected IDs never dispatch (verify via Mailpit on staging).',
];

export const description = `When the refund webhook endpoint is called more than ~50 times per minute, requests start returning HTTP 503. Customer impact is severe — refund confirmation emails are silently dropped, leading to support tickets within an hour of any bulk-refund batch.

Sherlock has produced a 4-layer RCA. The recommended fix has **low confidence (0.42)** because the codebase has three different webhook patterns and the right one for refund flow needs a human decision.

**Related:** TC-RET-142 (Refund webhook idempotency test), RET-87 (Refund SLA requirement).`;

export const comments: Comment[] = [
  { id: 'c1', author: 'Kishor Kadam',     role: 'QA Engineer', at: '2026-05-19T08:18:00+05:30', body: 'Filed after smoke run hit the 503 wall at \`process-all\`. Repro is reliable on staging once you seed > 60 refunds.' },
  { id: 'c2', author: 'Sherlock',         role: 'Agent',       at: '2026-05-19T08:21:00+05:30', body: 'Generated 4-layer RCA. Confidence on Recommended Fix is 0.42 — flagging for human review.' },
  { id: 'c3', author: 'Akshay Panchal',   role: 'QA Lead',     at: '2026-05-19T09:02:00+05:30', body: 'Assigning to Nadim. Please prioritise — refund SLA is in RET-87 and we ship Sprint 42 in 5 days.' },
  { id: 'c4', author: 'Nadim Siddiqui',   role: 'QA Engineer', at: '2026-05-19T09:34:00+05:30', body: 'Acked. Reproducing locally now. Will check if the async-job-queue pattern from RET-204 fits here.' },
  { id: 'c5', author: 'Yogesh Mohite',    role: 'Sr QA · Admin', at: '2026-05-19T09:48:00+05:30', body: 'Linked TC-RET-142 (idempotency) — make sure the fix keeps that case passing.' },
];

export const activity: ActivityEvent[] = [
  { id: 'a01', kind: 'created',     at: '2026-05-19T08:14:00+05:30', actor: 'Kishor Kadam',   text: 'Filed defect DEF-318 from test run TR-RET-2026-05-19-amR-Sm' },
  { id: 'a02', kind: 'agent',       at: '2026-05-19T08:21:00+05:30', actor: 'Sherlock',       text: 'Generated 4-layer RCA · overall confidence 0.42' },
  { id: 'a03', kind: 'comment',     at: '2026-05-19T08:21:00+05:30', actor: 'Sherlock',       text: 'Flagged Recommended Fix for human review (confidence < 0.5)' },
  { id: 'a04', kind: 'status',      at: '2026-05-19T08:55:00+05:30', actor: 'system',         text: 'Status: New → Open · Triage' },
  { id: 'a05', kind: 'comment',     at: '2026-05-19T09:02:00+05:30', actor: 'Akshay Panchal', text: 'Assigned to Nadim Siddiqui' },
  { id: 'a06', kind: 'assigned',    at: '2026-05-19T09:02:00+05:30', actor: 'Akshay Panchal', text: 'Assignee → Nadim Siddiqui' },
  { id: 'a07', kind: 'linked',      at: '2026-05-19T09:11:00+05:30', actor: 'Yogesh Mohite',  text: 'Linked TC-RET-142 (Refund webhook idempotency)' },
  { id: 'a08', kind: 'linked',      at: '2026-05-19T09:12:00+05:30', actor: 'Yogesh Mohite',  text: 'Linked requirement RET-87 (Refund SLA)' },
  { id: 'a09', kind: 'jira-sync',   at: '2026-05-19T09:13:00+05:30', actor: 'system',         text: 'Synced to Jira as RET-318' },
  { id: 'a10', kind: 'comment',     at: '2026-05-19T09:34:00+05:30', actor: 'Nadim Siddiqui', text: 'Reproducing locally; investigating async-job-queue path' },
  { id: 'a11', kind: 'agent',       at: '2026-05-19T09:40:00+05:30', actor: 'Curator',        text: 'Clustered with DEF-291, DEF-303 (refund-webhook family · cluster R-7)' },
  { id: 'a12', kind: 'comment',     at: '2026-05-19T09:48:00+05:30', actor: 'Yogesh Mohite',  text: 'Tagged: refund / webhook / race-condition' },
];

export const linkedEntities: LinkedEntity[] = [
  { kind: 'test-case',   id: 'TC-RET-142', title: 'Refund webhook idempotency',  status: 'Passing on main, failing on Nadim-feat-refund-async' },
  { kind: 'requirement', id: 'RET-87',     title: 'Refund SLA · webhook dispatch ≤ 5s', status: 'Active · Sprint 42 scope' },
  { kind: 'defect',      id: 'DEF-291',    title: 'Refund webhook flaky on cold start',  status: 'Closed · Sprint 41 · same cluster' },
  { kind: 'defect',      id: 'DEF-303',    title: 'Webhook signature mismatch under retry', status: 'Open · P2 · same cluster' },
];

export const rightRail: RightRailMeta = {
  status: 'Open · Triage',
  allowedTransitions: ['In Progress', 'Needs Info', 'Closed · Won\'t Fix'],
  assignee: { name: 'Nadim Siddiqui',   initials: 'NS' },
  reporter: { name: 'Kishor Kadam',     initials: 'KK' },
  severity: 'P1',
  priority: 'High',
  sprint:   'RET Sprint 42',
  environment: 'staging',
  tags: ['refund', 'webhook', 'race-condition'],
  jiraIssue: { key: 'RET-318', status: 'In Triage', synced: true },
  watchers: [
    { name: 'Akshay Panchal', initials: 'AP' },
    { name: 'Yogesh Mohite',  initials: 'YM' },
    { name: 'Kishor Kadam',   initials: 'KK' },
    { name: 'Nadim Siddiqui', initials: 'NS' },
  ],
};
