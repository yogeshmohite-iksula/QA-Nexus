export function ReproductionSteps({ steps }: { steps: string[] }) {
  return (
    <section role="region" aria-label="Reproduction steps" data-canonical-section="reproduction"
             className="space-y-3">
      <h2 className="font-mono text-[12px] uppercase tracking-[0.08em] text-[color:var(--t3)]">
        Reproduction steps
      </h2>
      <ol className="list-decimal pl-5 space-y-1.5 text-[14px] leading-[1.55] text-[color:var(--t2)] marker:text-[color:var(--t4)] marker:font-mono">
        {steps.map((s, i) => (<li key={i}>{s}</li>))}
      </ol>
    </section>
  );
}
