import { F22DefectDetail } from '@/components/f22-defect-detail/F22DefectDetail';
import { defect, rcaLayers, comments, activity, linkedEntities, rightRail, description, reproductionSteps } from '@/components/f22-defect-detail/canned-data';

// Server Component. AdminShell is mounted in the (app) layout — do NOT
// re-mount it here. This route owns only the <main> content area.
// Client interactivity (accordion, drawer, localStorage) is isolated
// inside F22DefectDetail's sub-components marked "use client".

export default function DefectDetailPage({ params }: { params: { id: string } }) {
  // `params.id` would normally feed the data layer (TanStack Query).
  // For PM1 pilot the page renders verbatim canned data; BE+1 will wire
  // the query in a later milestone.
  void params;
  return (
    <F22DefectDetail
      defect={defect}
      rcaLayers={rcaLayers}
      comments={comments}
      activity={activity}
      linkedEntities={linkedEntities}
      rightRail={rightRail}
      description={description}
      reproductionSteps={reproductionSteps}
    />
  );
}
