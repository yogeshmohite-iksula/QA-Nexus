import { Clock, User } from 'lucide-react';
import type { Defect } from './types';

const SEV_CLASSES: Record<string,string> = {
  P0: 'bg-[color-mix(in_srgb,var(--fail)_14%,transparent)] text-[color:var(--fail)] border-[color-mix(in_srgb,var(--fail)_34%,transparent)]',
  P1: 'bg-[color-mix(in_srgb,var(--fail)_14%,transparent)] text-[color:var(--fail)] border-[color-mix(in_srgb,var(--fail)_34%,transparent)]',
  P2: 'bg-[color-mix(in_srgb,var(--warn)_14%,transparent)] text-[color:var(--warn)] border-[color-mix(in_srgb,var(--warn)_34%,transparent)]',
  P3: 'bg-[color-mix(in_srgb,var(--info)_12%,transparent)] text-[color:var(--info)] border-[color-mix(in_srgb,var(--info)_30%,transparent)]',
};

function relativeTime(iso: string): string {
  const diff = (Date.now() - new Date(iso).getTime()) / 36e5;
  if (diff < 1) return Math.round(diff * 60) + 'm ago';
  if (diff < 24) return Math.round(diff) + 'h ago';
  return Math.round(diff / 24) + 'd ago';
}

export function DefectHeader({ defect }: { defect: Defect }) {
  return (
    <section role="region" aria-label={`Defect header: ${defect.id} · ${defect.title}`}
             data-canonical-section="defect-header"
             className="space-y-3">
      <div className="flex items-start gap-3 flex-wrap">
        <span className={`inline-flex items-center px-2 py-0.5 rounded-md border font-mono text-[10.5px] font-bold tracking-[0.04em] ${SEV_CLASSES[defect.severity]}`}>
          {defect.severity}
        </span>
        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md border border-[color:var(--border)] bg-[color:var(--surface-2)] text-[color:var(--t1)] text-[11.5px] font-medium">
          <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--warn)]" aria-hidden="true" />
          {defect.status}
        </span>
        <span className="font-mono text-[12px] text-[color:var(--t3)]">{defect.id}</span>
      </div>

      <h1 className="font-[\'DM_Sans\'] text-[20px] leading-7 font-bold text-[color:var(--t1)] tracking-[-0.01em] md:text-[24px] md:leading-8 text-pretty">
        {defect.title}
      </h1>

      <div className="flex items-center gap-3 flex-wrap text-[12px] text-[color:var(--t3)]">
        <span className="inline-flex items-center gap-1.5">
          <User className="h-3 w-3" aria-hidden="true" />
          <span>Reported by <b className="text-[color:var(--t1)] font-semibold">{defect.reporter}</b></span>
        </span>
        <span className="text-[color:var(--t4)]">·</span>
        <span className="inline-flex items-center gap-1.5">
          <Clock className="h-3 w-3" aria-hidden="true" />
          <time dateTime={defect.reportedAt} className="font-mono">{relativeTime(defect.reportedAt)}</time>
        </span>
      </div>
    </section>
  );
}
