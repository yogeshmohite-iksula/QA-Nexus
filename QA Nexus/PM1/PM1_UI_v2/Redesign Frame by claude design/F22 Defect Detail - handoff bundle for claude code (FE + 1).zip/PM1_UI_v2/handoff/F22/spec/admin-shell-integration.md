# AdminShell Integration — F22 Defect Detail

## Hard Rule 14 — shell parity

The left rail and top utility bar are **locked**. F22 only owns the
`<main>` content area. The shell is already mounted in the route group
layout:

```
apps/web/src/app/(app)/layout.tsx   ← AdminShell lives here
apps/web/src/app/(app)/defects/[id]/page.tsx   ← F22 route entry
```

If the shell isn't mounted in `(app)/layout.tsx` yet, wrap the route's
return with `<AdminShell>` — but do **not** re-implement its internals.
The shell must remain a single component, used across every `(app)`
route.

## Active rail item

When this route is open, the rail's active item must be **Defects /
Failures** under the **ANALYSE** section (`data-tone="fail"`), and the
ANALYSE section must auto-expand on load even if `localStorage` says
collapsed (the override is preserved on next visit per the demo
collapsible nav contract).

The route does not need to do anything special to make this happen —
AdminShell reads the active path from `usePathname()`. Just confirm
the shell's path-to-active-item map includes `/defects/[id]`.

## What F22 may NOT do

- Mount a second nav.
- Override topbar layout (project pill, search, mode toggle, user pill).
- Touch the rail-collapse toggle or its `localStorage` key.
- Add a second app-level scrollbar — content scrolls within `<main>` only.

## What F22 owns

- The grid inside `<main>` — 1 col on mobile, 2-col (7/3) on desktop.
- The right rail / drawer pair (`RightRail.tsx`).
- The breadcrumb `<nav role="navigation" aria-label="Breadcrumb">` at
  the top of `<main>`.
- All ARIA labels per `spec/spec.json`.

## Mode toggle

The route does **not** lock the mode toggle. Operate is the default
mode for defect triage. Review and Prove remain selectable per the
shell's own contract.
