# F22 Defect Detail — Handoff Bundle for Claude Code (FE+1)

Drop the contents of this bundle into:
```
~/AI_Tester_Project/Project10-QA_Nexus/apps/web/
```

The bundle is structured so file paths map 1:1 to where they go in the Next.js app:

```
apps/web/src/app/(app)/defects/[id]/page.tsx
apps/web/components/f22-defect-detail/<components>.tsx
apps/web/components/f22-defect-detail/canned-data.ts
apps/web/components/f22-defect-detail/spec.json
```

## How FE+1 should use this bundle in the frame-port skill workflow

The frame-port v2.2 skill is a 7-step workflow:

| Step | Status | Action |
|---|---|---|
| 1 · Read brief & design | required | Open `README.md` + browse the v2 HTML at `Redesign Frame by claude design/F22 Defect Detail v2.html` |
| 2 · Extract sections + ARIA anchors | **SKIP** | Pre-done in `spec/spec.json` (schemaVersion 3) |
| 3 · Build canned data | **SKIP** | Pre-done in `canned-data.ts` — verbatim values per brief |
| 4 · Generate components | required | Components are scaffolded; FE+1 wires them into route + adds polish |
| 5 · Wire shell integration | required | Wrap with existing `<AdminShell>` per `spec/admin-shell-integration.md` |
| 6 · Verify diff-probe | required | Run v2.2 diff-probe against the v2 HTML reference |
| 7 · QA + commit | required | Visual + a11y + 320px no-scroll check |

## v2.2 diff-probe expectations

- `POTENTIAL_INVERSION` warns are **OK** in: agent confidence chips (semantic colors invert for low-conf), amber banner color usage
- `MISSING` blocks if: any region missing `data-canonical-section` attr, any agent reference without `<AgentName>` wrapper, any user-visible string hardcoded (must reference `canned-data.ts`)
- `HARDCODED_COLOR` blocks: every color must be a CSS variable from `globals.css` (see `spec/tokens.md`)

## As-built vs. brief naming

| Brief name | As-built component | Notes |
|---|---|---|
| (root) | `page.tsx` (route) → `F22DefectDetailPage` | Next.js App Router entry |
| Defect header + status | `DefectHeader.tsx` | Title + status pill + severity badge + reporter |
| Action row | `ActionRow.tsx` | Reopen / Convert to Jira / Link TC / Assign / More |
| Amber banner | `AmberBanner.tsx` | Conditionally rendered (confidence < 0.5) |
| Description | `DescriptionSection.tsx` | TipTap output placeholder |
| Reproduction | `ReproductionSteps.tsx` | Numbered list |
| **Sherlock RCA accordion** | `RcaAccordion.tsx` + `RcaLayer.tsx` | The novel component — see brief |
| Activity timeline | `ActivityTimeline.tsx` | 12 entries verbatim |
| Linked entities | `LinkedEntities.tsx` | TC-RET-142 + RET-87 + related |
| Right rail | `RightRail.tsx` | Sticky desktop / drawer mobile |
| Agent naming | `agents/AgentName.tsx` | Rule 15 micro-component |

## Critical reminders

- **AdminShell is locked** — F22 only owns the `<main>` content area. See `spec/admin-shell-integration.md`.
- **No hardcoded colors** — every color references a CSS variable from `apps/web/src/app/globals.css`. Token reference in `spec/tokens.md`.
- **Agent names** — every reference uses `<AgentName code="sherlock" />` etc. Never plain "AI" or "the system".
- **Server vs Client** — accordion state, drawer state, and localStorage live in `"use client"` components. The route file is a Server Component by default.
- **localStorage key** — `qa-nexus.f22.rca.expanded-layers` stores a JSON array of layer IDs.
- **Deep-link** — `?rca=2` expands layer 2 on load.

## Stack contract

- React 19 · Next.js 15 App Router
- Tailwind v4 CSS-first (existing CSS vars only — no `@theme` extensions)
- TanStack Query v5 (props mode for now)
- lucide-react for icons
- shadcn/ui primitives — Accordion, Sheet (drawer), Tooltip, Badge, Button
- Sonner for toasts
- Framer Motion — accordion + drawer transitions only

## Banned list (PM1)

No MUI · Chakra · Mantine · daisyui · material-tailwind · Material Design 3 tokens · Redis · FastAPI · MDN `tertiary`/`error`/`primaryContainer` Material tokens.

## File map

- `apps/web/src/app/(app)/defects/[id]/page.tsx` — route + Server Component
- `apps/web/components/f22-defect-detail/F22DefectDetail.tsx` — main content composition
- `apps/web/components/f22-defect-detail/DefectHeader.tsx`
- `apps/web/components/f22-defect-detail/ActionRow.tsx`
- `apps/web/components/f22-defect-detail/AmberBanner.tsx`
- `apps/web/components/f22-defect-detail/DescriptionSection.tsx`
- `apps/web/components/f22-defect-detail/ReproductionSteps.tsx`
- `apps/web/components/f22-defect-detail/RcaAccordion.tsx`
- `apps/web/components/f22-defect-detail/RcaLayer.tsx`
- `apps/web/components/f22-defect-detail/ActivityTimeline.tsx`
- `apps/web/components/f22-defect-detail/LinkedEntities.tsx`
- `apps/web/components/f22-defect-detail/RightRail.tsx`
- `apps/web/components/f22-defect-detail/agents/AgentName.tsx`
- `apps/web/components/f22-defect-detail/canned-data.ts`
- `apps/web/components/f22-defect-detail/spec.json`
- `apps/web/components/f22-defect-detail/types.ts`
