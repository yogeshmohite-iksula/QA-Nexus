'use client';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ThumbsUp, ThumbsDown, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';
import type { RcaLayer as RcaLayerType } from './types';

interface Props {
  layer: RcaLayerType;
  index: number;
  expanded: boolean;
  onToggle: () => void;
}

function confidenceTone(c: number): { label: string; bg: string; ring: string; text: string } {
  if (c >= 0.85) return { label: 'High',  bg: 'color-mix(in srgb, var(--pass) 14%, transparent)', ring: 'color-mix(in srgb, var(--pass) 34%, transparent)', text: 'var(--pass)' };
  if (c >= 0.65) return { label: 'Medium', bg: 'color-mix(in srgb, var(--info) 12%, transparent)', ring: 'color-mix(in srgb, var(--info) 30%, transparent)', text: 'var(--info)' };
  if (c >= 0.50) return { label: 'Low',    bg: 'color-mix(in srgb, var(--warn) 14%, transparent)', ring: 'color-mix(in srgb, var(--warn) 34%, transparent)', text: 'var(--warn)' };
  return            { label: 'Needs review', bg: 'color-mix(in srgb, var(--warn) 14%, transparent)', ring: 'color-mix(in srgb, var(--warn) 34%, transparent)', text: 'var(--warn)' };
}

export function RcaLayer({ layer, index, expanded, onToggle }: Props) {
  const tone = confidenceTone(layer.confidence);
  const headerId = `rca-${layer.id}-header`;
  const panelId  = `rca-${layer.id}-panel`;

  return (
    <article role="article" aria-label={`Sherlock RCA layer ${index}: ${layer.title}`}
             data-canonical-section={`rca-layer-${index}`}>
      <h3>
        <button
          id={headerId}
          type="button"
          aria-expanded={expanded}
          aria-controls={panelId}
          onClick={onToggle}
          className="w-full min-h-[44px] flex items-center gap-3 px-4 py-3 text-left bg-transparent hover:bg-[color:var(--surface-2)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[color:var(--secondary)]"
        >
          <span className="font-mono text-[10px] text-[color:var(--t3)] tabular-nums">0{index}</span>
          <span className="font-[\'DM_Sans\'] text-[14px] font-semibold text-[color:var(--t1)] flex-1 min-w-0">
            {layer.title}
          </span>
          <span className="inline-flex items-center gap-1 font-mono text-[10.5px] font-bold px-2 py-0.5 rounded-sm border"
                style={{ background: tone.bg, borderColor: tone.ring, color: tone.text }}>
            {layer.confidence.toFixed(2)} · {tone.label}
          </span>
          <ChevronDown
            className="h-4 w-4 text-[color:var(--t3)] transition-transform"
            style={{ transform: expanded ? 'rotate(180deg)' : 'rotate(0deg)' }}
            aria-hidden="true"
          />
        </button>
      </h3>

      <AnimatePresence initial={false}>
        {expanded ? (
          <motion.div
            id={panelId}
            role="region"
            aria-labelledby={headerId}
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.28, ease: [0.4, 0, 0.2, 1] }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 pt-1 space-y-3">
              <p className="text-[14px] leading-[1.55] text-[color:var(--t2)] text-pretty">
                {layer.body}
              </p>

              {layer.code ? (
                <pre className="rounded-md border border-[color:var(--border)] bg-[color:var(--surface-2)] text-[13px] leading-[1.55] text-[color:var(--t2)] font-mono p-3 overflow-x-auto">
                  <code>{layer.code}</code>
                </pre>
              ) : null}

              {layer.logLineRef ? (
                <a href={layer.logLineRef}
                   className="inline-flex items-center gap-1 text-[12px] font-medium text-[color:var(--secondary)] hover:underline">
                  Jump to evidence <ExternalLink className="h-3 w-3" aria-hidden="true" />
                </a>
              ) : null}

              <div className="flex items-center gap-2 pt-2 border-t border-[color:var(--border)] -mx-4 px-4 -mb-4 pb-4">
                <span className="font-mono text-[10.5px] uppercase tracking-[0.06em] text-[color:var(--t3)]">
                  Was this useful?
                </span>
                <button type="button"
                        onClick={() => toast.success('Marked as accurate')}
                        aria-label="Mark as accurate"
                        className="inline-flex h-11 w-11 items-center justify-center rounded-md text-[color:var(--t3)] hover:text-[color:var(--pass)] hover:bg-[color-mix(in_srgb,var(--pass)_8%,transparent)]">
                  <ThumbsUp className="h-4 w-4" />
                </button>
                <button type="button"
                        onClick={() => toast.info('Feedback recorded')}
                        aria-label="Disagree"
                        className="inline-flex h-11 w-11 items-center justify-center rounded-md text-[color:var(--t3)] hover:text-[color:var(--fail)] hover:bg-[color-mix(in_srgb,var(--fail)_8%,transparent)]">
                  <ThumbsDown className="h-4 w-4" />
                </button>
              </div>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </article>
  );
}
